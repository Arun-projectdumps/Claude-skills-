---
description: Build a low-poly character in Blender (lowpolymodel skill)
argument-hint: <describe the character, e.g. "sleepy girl with round glasses and yellow jacket">
---
Use the `lowpolymodel` skill (load it with the Skill tool) to build this character in the running Blender scene: $ARGUMENTS

If no description was given, ask what character to make, and offer the three base styles (faceted chibi human, smooth glowing robot, faceted mascot blob) as starting points.
