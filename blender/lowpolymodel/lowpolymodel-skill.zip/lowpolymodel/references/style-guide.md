# Style guide: what the reference designs are doing

## Shared look
- Toy-like proportions, readable silhouettes, few big shapes, and no small surface detail.
- Moody lighting: very dark warm or night-blue background, one warm key light from upper-front-left,
  a cool rim light from behind. Colors are deep and saturated, not pastel. `lpm.stage('warm')` /
  `stage('night')` reproduce this.
- Faces carry the emotion: big glossy eyes, heavy blocky brows, tiny nose, small mouth.
  Expression comes from brow angle, eyelid droop (`eye(half_lid=)`), and eye/mouth shapes on bots.

## 1. Faceted chibi human (@agentpoly guy, canwebuildthis girl) -> `examples/chibi.py`
- Head is ~40% of total height, slightly wider than tall (`scale x 1.1-1.2`), visibly faceted
  (icosphere detail 2 + jitter), and the face is a little flattened at the front.
- Hair is a separate faceted cap, bigger than the skull, with a fringe made of 4-6 pyramid strands across the
  forehead. Variants are spiky (pyramids pointing up/out), long (a rounded slab behind), and bun.
- Eyes are black glossy ovals with one white catch-light on the same side on both eyes. Brows are thick dark bars
  that sit just above the eyes. Tilt the brows for emotion (inner ends up = worried, down = angry).
- Nose is a 4-sided pyramid. Mouth is a small flattened red-brown blob.
- Clothes are a hoodie block (dark navy or yellow jacket) with a hood collar ring, two orange drawstrings, and a front
  pocket. Legs are simple dark capsules, and shoes are beveled blocks.
- Accessories are round glasses (`ring` x2 + bridge), headphones (two `facet` cups + a `lathe` band), and a held
  phone (a thin dark block on the hand bone).

## 2. Smooth toy robot (agentcinder Claude-bot) -> `examples/bot.py`
- The body is a single rounded box with a large corner radius, in glossy orange.
- The face is a dark glossy rounded screen inset on the front. Eyes are glowing warm-white rounded squares, the
  mouth is a short glowing bar, and an optional glowing cheek dot sits beside it.
- The antenna is a thin stalk with a glowing white bulb on its own bone so it can wobble.
- Arms are short capsules on shoulder balls, and legs are short rounded stubs. This style is smooth, not faceted.
- Expressions are made with the eye shapes: squares = neutral, ^ ^ bars = happy, flat bars = sleepy, and
  tilted bars = sad or angry.

## 3. Faceted mascot blob (orange starburst buddy) -> `examples/buddy.py`
- A cluster of faceted lobes around a core, flattened front to back, in Claude orange.
- Eyes are two tall black slits. Two nub feet hold it up, and there are no arms (add small lobes on bones if needed).

## 4. Boxy critter (orange "Found it!" block guy)
- One wide `block` body with slight bevel and flat shading, ^ ^ arc eyes (two `spike`s or thin bent
  blocks), soft blush (`facet` flattened, `blush` color), a wedge nose (`spike` segments=4), and four thin
  block legs, each on its own bone with x range ±25 and leg gaps of at least 0.05.

## Improvising new characters
Mix and match: chibi body + robot screen-head, blob + hoodie, bot with hair, animals (ears = `spike`
segments=3-4 or flattened `facet`, tail = chain of `limb`s on 2-3 bones each ±20°). Keep the rules:
big head or one dominant shape, a dark moody palette with one warm accent, glow only on eyes/UI/bulbs,
and every moving piece rigid on a bone with a tested range.
