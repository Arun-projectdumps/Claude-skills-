# Smooth toy robot ("agentcinder" Claude-bot look): rounded body, dark glossy screen face,
# glowing eyes/mouth, antenna with a glowing bulb. Smooth = beveled blocks + smooth shading +
# weighted normals, still cheap (~2-3k tris).
import lpm
from mathutils import Vector as V

# ---------------- PARAMS
NAME = "Bot"
BODY = "claude"          # body color (palette name or (r,g,b))
GLOW = "warm"            # warm | white | cyan | green | red
W, D, H = 1.40, 1.10, 1.10   # body size
ROUND = 0.26             # corner radius (0.1 boxy .. 0.4 pebble)
ANTENNA_X = 0.25
MOOD = "neutral"         # neutral | happy | sad  (changes eye/mouth shapes)
# ----------------

lpm.begin(NAME)
P = NAME + "_"
BZ = 0.37 + H / 2        # body center (legs below)
FRONT = -D / 2

body_m = lpm.mat("bot_body", BODY, rough=0.35, spec=0.5)
lpm.block(P + "body", (W, D, H), (0, 0, BZ), bevel=ROUND, segments=4, smooth=True, material=body_m)
lpm.block(P + "screen", (W * 0.77, 0.08, H * 0.6), (0, FRONT + 0.02, BZ + 0.05), bevel=0.1, segments=3, smooth=True,
          material=lpm.mat("bot_screen", "screen", rough=0.18, spec=1.0))
fz = FRONT - 0.03
if MOOD == "happy":      # ^ ^ eyes = two tilted bars each
    for s in (1, -1):
        for t in (1, -1):
            lpm.glow_rect(P + "eye%s%d" % ("L" if s > 0 else "R", t), (0.13, 0.04, 0.04),
                          (0.24 * s + 0.045 * t, fz, BZ + 0.12), color=GLOW, rot=(0, -35 * t, 0))
else:
    eh = 0.2 if MOOD == "neutral" else 0.09
    for s in (1, -1):
        lpm.glow_rect(P + "eye" + ("L" if s > 0 else "R"), (0.2, 0.04, eh), (0.24 * s, fz, BZ + 0.12), color=GLOW)
lpm.glow_rect(P + "mouth", (0.17, 0.04, 0.045), (0, fz, BZ - 0.08), color=GLOW, rot=(0, 0, 0) if MOOD != "sad" else (0, 8, 0))
lpm.glow_ball(P + "cheek", 0.035, (0.2, fz, BZ - 0.1), color=GLOW, strength=14)

# antenna (own bone so it can wobble)
top = BZ + H / 2
lpm.lathe(P + "ant_base", [(0.07, top - 0.03), (0.07, top + 0.02), (0.035, top + 0.04)], (ANTENNA_X, 0, 0),
          segments=10, smooth=True, material=body_m)
lpm.lathe(P + "ant_stalk", [(0.025, 0), (0.02, 1)], segments=6, smooth=True, material=body_m,
          start=(ANTENNA_X, 0, top - 0.03), end=(ANTENNA_X, 0, top + 0.45))
lpm.glow_ball(P + "ant_bulb", 0.085, (ANTENNA_X, 0, top + 0.5), color="white", strength=18)

# arms: shoulder ball on the body + capsule whose round end sits on the pivot
for s, sd in ((1, "L"), (-1, "R")):
    lpm.ball(P + "shoulder" + sd, 0.11, (s * (W / 2 + 0.02), 0, BZ), segments=10, rings=5, material=body_m)
    lpm.limb(P + "arm" + sd, (s * (W / 2 + 0.1), 0, BZ), (s * (W / 2 + 0.16), 0, BZ - 0.32), 0.1, 0.09,
             segments=10, smooth=True, material=body_m)
# legs: rounded stubs
for s, sd in ((1, "L"), (-1, "R")):
    lpm.block(P + "leg" + sd, (0.26, 0.28, 0.34), (s * W * 0.24, 0, 0.17), bevel=0.1, segments=3, smooth=True,
              material=body_m)

R = lpm.rig(P + "rig", [
    ("root",    (0, 0, 0),                    (0, 0, 0.3),                  None,   None, 0.1),
    ("body",    (0, 0, 0.40),                 (0, 0, top),                  "root", {"x": (-10, 10), "y": (-20, 20), "z": (-8, 8)}, 0.45),
    ("antenna", (ANTENNA_X, 0, top - 0.03),   (ANTENNA_X, 0, top + 0.5),    "body", {"x": (-25, 25), "z": (-25, 25)}, 0.1),
    ("arm.L",   (W / 2 + 0.1, 0, BZ),         (W / 2 + 0.16, 0, BZ - 0.32), "body", {"x": (-60, 60), "z": (-5, 40)}, 0.14),
    ("arm.R",   (-W / 2 - 0.1, 0, BZ),        (-W / 2 - 0.16, 0, BZ - 0.32), "body", {"x": (-60, 60), "z": (-40, 5)}, 0.14),
    ("leg.L",   (W * 0.24, 0, 0.40),          (W * 0.24, 0, 0.0),           "root", {"x": (-25, 25)}, 0.2),
    ("leg.R",   (-W * 0.24, 0, 0.40),         (-W * 0.24, 0, 0.0),          "root", {"x": (-25, 25)}, 0.2),
])
lpm.attach_prefix(R, {
    "body": [P + k for k in ("body", "screen", "eye", "mouth", "cheek", "ant_base", "shoulder")],
    "antenna": [P + "ant_stalk", P + "ant_bulb"],
    "arm.L": [P + "armL"], "arm.R": [P + "armR"], "leg.L": [P + "legL"], "leg.R": [P + "legR"],
})
lpm.check()
