# Faceted mascot blob (orange "starburst buddy" look): cluster of low-poly lobes, slit eyes, nub feet.
import lpm, math
from mathutils import Vector as V

# ---------------- PARAMS
NAME = "Buddy"
COLOR = "claude"
LOBES = (90, 28, 152, -22, 202)   # lobe angles (deg) around the face, 90 = top
LOBE_R = 0.25
EYES = "slits"                     # slits | dots
# ----------------

lpm.begin(NAME)
P = NAME + "_"
C = V((0, 0, 0.64))
lpm.facet(P + "core", 0.42, C, (1, 0.72, 1), detail=2, jitter=0.05, material=COLOR)
for i, a in enumerate(LOBES):
    r = math.radians(a)
    lpm.facet(P + "lobe%d" % i, LOBE_R, C + V((math.cos(r) * 0.4, 0.02, math.sin(r) * 0.4)), (1, 0.72, 1),
              detail=2, jitter=0.07, seed=i + 3, material=COLOR)
fy = -0.42 * 0.72 - 0.005
for s in (1, -1):
    if EYES == "slits":
        lpm.block(P + "eye" + ("L" if s > 0 else "R"), (0.075, 0.05, 0.2), (0.11 * s, fy, C.z + 0.03), material="black")
    else:
        lpm.eye(P + "eye" + ("L" if s > 0 else "R"), (0.12 * s, fy, C.z + 0.04), r=0.06)
for s, sd in ((1, "L"), (-1, "R")):
    lpm.facet(P + "foot" + sd, 0.13, (0.15 * s, -0.03, 0.15), (1, 1.15, 0.9), detail=1, jitter=0.06, material=COLOR)

R = lpm.rig(P + "rig", [
    ("root",   (0, 0, 0),        (0, 0, 0.2),    None,   None, 0.1),
    ("body",   (0, 0, 0.24),     (0, 0, 1.3),    "root", {"x": (-12, 12), "y": (-25, 25), "z": (-10, 10)}, 0.30),
    ("foot.L", (0.15, 0, 0.22),  (0.15, 0, 0.0), "root", {"x": (-30, 30)}, 0.15),
    ("foot.R", (-0.15, 0, 0.22), (-0.15, 0, 0.0), "root", {"x": (-30, 30)}, 0.15),
])
lpm.attach_prefix(R, {"body": [P + "core", P + "lobe", P + "eye"], "foot.L": [P + "footL"], "foot.R": [P + "footR"]})
lpm.check()
