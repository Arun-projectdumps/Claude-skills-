# Faceted chibi human (big low-poly head, hoodie) - the "@agentpoly" / "canwebuildthis" look.
# Run:  bsend.py examples/chibi.py      Tweak the PARAMS block to improvise new characters.
import lpm
from mathutils import Vector as V

# ---------------- PARAMS
NAME = "Chibi"
HAIR = "mop"            # mop | spiky | long | bun
GLASSES = False
SLEEPY = 0.0            # 0..0.7 eyelid droop
SKIN, HAIR_C, TOP, PANTS, SHOES = "skin", "hair", "navy", "charcoal", "charcoal"
HEAD_R = 0.46           # head radius (chibi = 0.42..0.52 for a ~2.2 tall figure)
SEED = 7
# ----------------

lpm.begin(NAME)
P = NAME + "_"
HZ = 1.88                                   # head center height
NECK = V((0, 0, 1.40))                      # head pivot

# --- head (bone: head)
lpm.facet(P + "head", HEAD_R, (0, 0, HZ), (1.12, 1.0, 1.0), detail=2, jitter=0.05, seed=SEED,
          material=SKIN, flatten_front=0.12)
for s in (1, -1):
    x = 0.165 * s
    lpm.eye(P + "eye" + ("L" if s > 0 else "R"), (x, -HEAD_R * 0.84, HZ - 0.02), r=0.088, half_lid=SLEEPY)
    lpm.block(P + "brow" + ("L" if s > 0 else "R"), (0.17, 0.05, 0.045), (x, -HEAD_R * 0.86, HZ + 0.11),
              material=HAIR_C, rot=(0, 4 * s, 0))
    lpm.facet(P + "ear" + ("L" if s > 0 else "R"), 0.1, (HEAD_R * 1.1 * s, 0.02, HZ - 0.02), (0.6, 1, 1.2),
              detail=1, jitter=0.08, material=SKIN)
lpm.spike(P + "nose", (0, -HEAD_R * 0.80, HZ - 0.09), (0, -HEAD_R * 0.98, HZ - 0.13), 0.045, segments=4, material=SKIN)
lpm.facet(P + "mouth", 0.05, (0, -HEAD_R * 0.80, HZ - 0.24), (1.1, 0.4, 0.45), detail=1, jitter=0, material="lip")
if GLASSES:
    for s in (1, -1):
        lpm.ring(P + "glass" + ("L" if s > 0 else "R"), 0.13, 0.012, (0.18 * s, -HEAD_R * 0.98, HZ - 0.02))
    lpm.block(P + "glass_bridge", (0.11, 0.02, 0.02), (0, -HEAD_R * 0.99, HZ), material="black")

# hair (all on head bone, so overlapping the skull is fine)
lpm.facet(P + "hair_cap", HEAD_R * 1.04, (0, 0.05, HZ + 0.08), (1.15, 1.02, 0.92), detail=2, jitter=0.07,
          seed=SEED + 1, material=HAIR_C)
if HAIR in ("mop", "long"):
    for i, x in enumerate((-0.32, -0.19, -0.06, 0.07, 0.2, 0.33)):          # fringe strands
        lpm.spike(P + "fringe%d" % i, (x, -HEAD_R * 0.62, HZ + 0.30), (x * 1.08, -HEAD_R * 0.93, HZ + 0.10 - 0.03 * (i % 2)),
                  0.09, segments=4, material=HAIR_C)
if HAIR == "spiky":
    for i in range(9):
        a = -1.1 + i * 0.275
        base = V((0.45 * a, 0.02, HZ + 0.32))
        lpm.spike(P + "spike%d" % i, base, base + V((0.18 * a, 0.08 * (i % 3 - 1), 0.28)), 0.1, segments=4, material=HAIR_C)
if HAIR == "long":
    lpm.block(P + "hair_back", (0.95, 0.25, 0.5), (0, 0.30, HZ - 0.08), bevel=0.08, material=HAIR_C)
if HAIR == "bun":
    lpm.facet(P + "bun", 0.17, (0, 0.18, HZ + 0.48), detail=1, material=HAIR_C)

# --- torso / hoodie (bone: spine)
lpm.block(P + "torso", (0.72, 0.42, 0.62), (0, 0, 1.05), bevel=0.06, segments=2, material=TOP)
lpm.facet(P + "hood", 0.34, (0, 0.04, 1.33), (1.0, 0.8, 0.22), detail=2, jitter=0.04, material=TOP)
lpm.lathe(P + "neck", [(0.11, 1.30), (0.11, 1.56)], segments=6, material=SKIN)
lpm.block(P + "pocket", (0.42, 0.03, 0.16), (0, -0.215, 0.88), bevel=0.01, material=TOP)
for s in (1, -1):
    lpm.block(P + "string" + ("L" if s > 0 else "R"), (0.025, 0.025, 0.2), (0.07 * s, -0.22, 1.2), material="string")

# --- arms (bones: arm.L / arm.R) - pivot = capsule round end, clear of the torso side
for s, sd in ((1, "L"), (-1, "R")):
    sh = V((0.49 * s, 0, 1.27))
    hand = V((0.53 * s, 0, 0.84))
    lpm.limb(P + "arm" + sd, sh, hand, 0.105, 0.095, segments=8, material=TOP)
    lpm.facet(P + "hand" + sd, 0.1, hand + V((0.0, 0, -0.07)), (0.9, 0.8, 1.0), detail=1, jitter=0.05, material=SKIN)

# --- legs (bones: leg.L / leg.R)
for s, sd in ((1, "L"), (-1, "R")):
    hip = V((0.17 * s, 0, 0.74))
    lpm.limb(P + "leg" + sd, hip, (0.17 * s, 0, 0.16), 0.125, 0.115, segments=8, material=PANTS)
    lpm.block(P + "shoe" + sd, (0.21, 0.32, 0.13), (0.17 * s, -0.04, 0.065), bevel=0.04, segments=2, material=SHOES)

# --- rig: X = nod/swing, Y = twist, Z = tilt/raise sideways (degrees)
R = lpm.rig(P + "rig", [
    ("root",  (0, 0, 0),         (0, 0, 0.35),       None,   None, 0.1),
    ("spine", (0, 0, 0.74),      (0, 0, 1.36),       "root", {"x": (-12, 15), "y": (-25, 25), "z": (-8, 8)}, 0.30),
    ("head",  tuple(NECK),       (0, 0, 2.38),       "spine", {"x": (-22, 20), "y": (-45, 45), "z": (-15, 15)}, 0.30),
    ("arm.L", (0.49, 0, 1.27),   (0.53, 0, 0.84),    "spine", {"x": (-75, 75), "z": (-10, 55)}, 0.16),
    ("arm.R", (-0.49, 0, 1.27),  (-0.53, 0, 0.84),   "spine", {"x": (-75, 75), "z": (-55, 10)}, 0.16),
    ("leg.L", (0.17, 0, 0.74),   (0.17, 0, 0.12),    "root", {"x": (-45, 45), "z": (-4, 12)}, 0.20),
    ("leg.R", (-0.17, 0, 0.74),  (-0.17, 0, 0.12),   "root", {"x": (-45, 45), "z": (-12, 4)}, 0.20),
])
lpm.attach_prefix(R, {
    "head": [P + k for k in ("head", "eye", "brow", "ear", "nose", "mouth", "glass", "hair", "fringe", "spike", "bun")],
    "spine": [P + k for k in ("torso", "hood", "neck", "pocket", "string")],
    "arm.L": [P + "armL", P + "handL"], "arm.R": [P + "armR", P + "handR"],
    "leg.L": [P + "legL", P + "shoeL"], "leg.R": [P + "legR", P + "shoeR"],
})
lpm.check()
