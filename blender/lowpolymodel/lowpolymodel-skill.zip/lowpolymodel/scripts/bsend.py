#!/usr/bin/env python3
"""Send Python to the running Blender (MCP for Blender add-on socket, default 127.0.0.1:9876).

Usage:
  bsend.py --load                 # (re)load lpm.py into Blender as module `lpm`
  bsend.py file.py [file2.py ...] # run local files inside Blender
  bsend.py -c "import lpm; ..."   # run an inline snippet
  echo "code" | bsend.py -        # run code from stdin

Each call auto-loads lpm first if Blender doesn't have it yet, so snippets can
always start with `import lpm`. Prints Blender's stdout or the error.
"""
import json, os, socket, sys

HOST, PORT = os.environ.get("BLENDER_HOST", "127.0.0.1"), int(os.environ.get("BLENDER_PORT", "9876"))
HERE = os.path.dirname(os.path.abspath(__file__))


def send(code, timeout=180):
    s = socket.create_connection((HOST, PORT), timeout=timeout)
    s.sendall(json.dumps({"type": "execute_code", "params": {"code": code}}).encode())
    buf = b""
    while True:
        chunk = s.recv(65536)
        if not chunk:
            break
        buf += chunk
        try:
            return json.loads(buf)
        except json.JSONDecodeError:
            continue
    return json.loads(buf)


def loader():
    with open(os.path.join(HERE, "lpm.py")) as f:
        src = f.read()
    return (
        "import sys, types\n"
        "m = types.ModuleType('lpm'); m.__file__ = %r\n"
        "exec(compile(%r, %r, 'exec'), m.__dict__)\n"
        "sys.modules['lpm'] = m\n"
        "print('lpm loaded', m.VERSION)\n"
    ) % (os.path.join(HERE, "lpm.py"), src, "lpm.py")


def run(code):
    r = send(code)
    if r.get("status") != "success":
        print("ERROR:", r.get("message", r))
        return 1
    out = r.get("result", {})
    print(out.get("result", out) if isinstance(out, dict) else out, end="")
    return 0


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    if argv[0] == "--load":
        return run(loader())
    # ensure lpm exists (cheap check), reload if file changed
    ensure = (
        "import sys, os\n"
        "m = sys.modules.get('lpm')\n"
        "print('NEED' if m is None or getattr(m,'_MTIME',0) != %r else 'OK', end='')\n"
    ) % os.path.getmtime(os.path.join(HERE, "lpm.py"))
    r = send(ensure)
    if "NEED" in str(r.get("result", "")):
        run(loader() + "m._MTIME = %r\n" % os.path.getmtime(os.path.join(HERE, "lpm.py")))
    if argv[0] == "-c":
        return run(argv[1])
    if argv[0] == "-":
        return run(sys.stdin.read())
    rc = 0
    for p in argv:
        with open(p) as f:
            rc |= run(f.read())
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
