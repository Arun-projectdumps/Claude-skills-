"""lpm - low-poly character kit, runs INSIDE Blender (loaded by bsend.py as module `lpm`).

Conventions
  * Units are meters, the character stands on z=0 and faces -Y (Blender front view).
  * +X is the character's LEFT, so bones/parts on +X are suffixed .L.
  * Every builder returns the new object, already linked to the current character collection.
  * Geometry is always closed (manifold), tris/quads only. N-gons are triangulated on creation.
  * Parts are rigid and bone-parented (no skin weights), so animation can never stretch or tear
    a mesh. Joints are made from a round end centered on the bone's pivot, so rotating about the
    pivot keeps the joint looking the same.
"""
VERSION = "1.0"

import bpy, bmesh, math, random
from mathutils import Vector, Matrix, Euler
from mathutils.bvhtree import BVHTree

# --------------------------------------------------------------------------- palette / materials
PALETTE = {
    # linear-ish RGB, tuned for the moody, warm low-poly look
    "skin": (0.62, 0.38, 0.28), "skin_light": (0.80, 0.55, 0.42), "skin_dark": (0.36, 0.20, 0.13),
    "hair": (0.045, 0.030, 0.022), "hair_brown": (0.16, 0.08, 0.04),
    "navy": (0.022, 0.032, 0.095), "denim": (0.06, 0.08, 0.14), "charcoal": (0.035, 0.035, 0.04),
    "orange": (0.80, 0.22, 0.06), "claude": (0.85, 0.32, 0.12), "rust": (0.45, 0.13, 0.04),
    "yellow": (0.85, 0.58, 0.04), "teal": (0.06, 0.25, 0.22), "olive": (0.15, 0.20, 0.10),
    "black": (0.008, 0.008, 0.008), "white": (0.9, 0.9, 0.9), "lip": (0.45, 0.07, 0.05),
    "screen": (0.006, 0.006, 0.010), "string": (0.45, 0.20, 0.08), "blush": (0.75, 0.15, 0.08),
}
GLOW = {"warm": (1.0, 0.82, 0.55), "white": (1.0, 0.97, 0.9), "cyan": (0.4, 0.9, 1.0),
        "red": (1.0, 0.2, 0.1), "green": (0.4, 1.0, 0.5)}


def _rgb(c):
    if isinstance(c, str):
        c = PALETTE.get(c) or GLOW.get(c)
    return tuple(c[:3])


def mat(name, color=None, rough=0.75, metal=0.0, glow=None, strength=6.0, spec=0.3):
    """Get/create a material. glow=<color> makes it emissive (eyes, screens, antenna bulbs)."""
    m = bpy.data.materials.get("lpm_" + name)
    if m is None:
        m = bpy.data.materials.new("lpm_" + name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    col = _rgb(color if color is not None else name)
    b = m.node_tree.nodes.get("Principled BSDF")
    b.inputs["Base Color"].default_value = (*col, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    if "Specular IOR Level" in b.inputs:
        b.inputs["Specular IOR Level"].default_value = spec
    if glow is not None:
        g = _rgb(glow)
        b.inputs["Emission Color"].default_value = (*g, 1)
        b.inputs["Emission Strength"].default_value = strength
        m.diffuse_color = (*g, 1)
    else:
        b.inputs["Emission Strength"].default_value = 0.0
        m.diffuse_color = (*col, 1)
    return m


def _m(x):
    if x is None or isinstance(x, bpy.types.Material):
        return x
    return mat(x)


# --------------------------------------------------------------------------- collections
_CUR = None


def begin(name):
    """Start (or rebuild) a character. Everything created after this goes in collection `name`."""
    global _CUR
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
    for o in list(col.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    _CUR = col
    return col


def current():
    return _CUR


def remove(*names):
    for n in names:
        o = bpy.data.objects.get(n)
        if o:
            bpy.data.objects.remove(o, do_unlink=True)


def _link(o, col=None):
    (col or _CUR or bpy.context.scene.collection).objects.link(o)
    return o


# --------------------------------------------------------------------------- mesh core
def _finish(name, bm, material=None, loc=(0, 0, 0), rot=None, smooth=False, weighted=False):
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
    bmesh.ops.dissolve_degenerate(bm, edges=bm.edges, dist=1e-6)
    ng = [f for f in bm.faces if len(f.verts) > 4]
    if ng:
        bmesh.ops.triangulate(bm, faces=ng, quad_method="BEAUTY", ngon_method="BEAUTY")
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces:
        f.smooth = smooth
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    if material is not None:
        me.materials.append(_m(material))
    o = bpy.data.objects.new(name, me)
    o.location = loc
    if rot is not None:
        o.rotation_euler = Euler([math.radians(a) for a in rot])
    if smooth and weighted:
        mod = o.modifiers.new("WeightedNormal", "WEIGHTED_NORMAL")
        mod.keep_sharp = True
    return _link(o)


def _aim(start, end):
    """Matrix taking +Z (0..len) onto the segment start->end."""
    d = Vector(end) - Vector(start)
    q = d.to_track_quat("Z", "Y")
    return q.to_matrix().to_4x4(), d.length


def _lathe_bm(profile, segments, twist=0.0):
    """profile: [(radius, z), ...] bottom->top. r==0 -> pole vertex. Open ends are capped with tri fans."""
    bm = bmesh.new()
    rings = []
    for k, (r, z) in enumerate(profile):
        if r <= 1e-6:
            rings.append([bm.verts.new((0, 0, z))])
        else:
            a0 = twist * k
            rings.append([bm.verts.new((r * math.cos(a0 + 2 * math.pi * i / segments),
                                        r * math.sin(a0 + 2 * math.pi * i / segments), z))
                          for i in range(segments)])
    if len(rings[0]) > 1:
        rings.insert(0, [bm.verts.new((0, 0, profile[0][1]))])
    if len(rings[-1]) > 1:
        rings.append([bm.verts.new((0, 0, profile[-1][1]))])
    for a, b in zip(rings, rings[1:]):
        n = segments
        if len(a) == 1 and len(b) == 1:
            continue
        for i in range(n):
            j = (i + 1) % n
            if len(a) == 1:
                bm.faces.new((a[0], b[j], b[i]))
            elif len(b) == 1:
                bm.faces.new((a[i], a[j], b[0]))
            else:
                bm.faces.new((a[i], a[j], b[j], b[i]))
    return bm


# --------------------------------------------------------------------------- primitives
def facet(name, r, loc, scale=(1, 1, 1), detail=2, jitter=0.05, seed=0, material="skin",
          smooth=False, rot=None, flatten_front=0.0):
    """Faceted low-poly sphere (icosphere + radial jitter). detail 1=20 tris, 2=80, 3=320.
    flatten_front pushes the -Y side inward (gives the flat 'face plane' of the reference heads)."""
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=detail, radius=r)
    rnd = random.Random(seed or hash(name) & 0xffff)
    for v in bm.verts:
        v.co *= 1.0 + rnd.uniform(-jitter, jitter)
        if flatten_front and v.co.y < 0:
            v.co.y *= 1.0 - flatten_front
        v.co = Vector((v.co.x * scale[0], v.co.y * scale[1], v.co.z * scale[2]))
    return _finish(name, bm, material, loc, rot, smooth)


def ball(name, r, loc, scale=(1, 1, 1), segments=12, rings=6, material="white", smooth=True, rot=None):
    """Smooth UV-style sphere built by lathe (quads + pole fans)."""
    prof = [(r * math.sin(math.pi * k / rings), -r * math.cos(math.pi * k / rings)) for k in range(rings + 1)]
    bm = _lathe_bm(prof, segments)
    for v in bm.verts:
        v.co = Vector((v.co.x * scale[0], v.co.y * scale[1], v.co.z * scale[2]))
    return _finish(name, bm, material, loc, rot, smooth)


def block(name, size, loc, bevel=0.0, segments=1, material="navy", smooth=False, rot=None):
    """Box. bevel>0 rounds the edges; with smooth=True gives the soft 'toy robot' look."""
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        v.co = Vector((v.co.x * size[0], v.co.y * size[1], v.co.z * size[2]))
    if bevel > 0:
        bevel = min(bevel, min(size) * 0.49)
        bmesh.ops.bevel(bm, geom=list(bm.edges) + list(bm.verts), offset=bevel, offset_type="OFFSET",
                        segments=segments, profile=0.5, affect="EDGES", clamp_overlap=True)
    return _finish(name, bm, material, loc, rot, smooth, weighted=smooth and bevel > 0)


def lathe(name, profile, loc=(0, 0, 0), segments=8, material="navy", smooth=False, rot=None, start=None, end=None):
    """Revolve [(r,z),...] around Z. Pass start/end instead of loc to aim it between two points
    (profile z then runs 0..1 and is scaled to the segment length)."""
    if start is not None:
        M, L = _aim(start, end)
        bm = _lathe_bm([(r, z * L) for r, z in profile], segments)
        bm.transform(M)
        return _finish(name, bm, material, start, None, smooth)
    return _finish(name, _lathe_bm(profile, segments), material, loc, rot, smooth)


def limb(name, start, end, r, r2=None, segments=8, material="navy", smooth=False, cap_rings=2):
    """Capsule from start to end (round ends centered ON start/end). Put start on the joint pivot:
    the round end then rotates in place, so the joint never opens or pokes through."""
    r2 = r if r2 is None else r2
    M, L = _aim(start, end)
    prof = []
    for k in range(cap_rings, 0, -1):            # bottom cap (around start)
        a = math.pi / 2 * k / cap_rings
        prof.append((r * math.cos(a), -r * math.sin(a)))
    steps = max(1, int(L / max(min(r, r2) * 1.5, 1e-3)))   # extra rings so the shaft can be tested
    for k in range(steps + 1):
        t = k / steps
        prof.append((r + (r2 - r) * t, L * t))
    for k in range(1, cap_rings + 1):            # top cap (around end)
        a = math.pi / 2 * k / cap_rings
        prof.append((r2 * math.cos(a), L + r2 * math.sin(a)))
    bm = _lathe_bm(prof, segments)
    bm.transform(M)
    return _finish(name, bm, material, start, None, smooth)


def spike(name, base, tip, r, segments=4, material="hair", smooth=False):
    """Cone/pyramid from base center to tip (hair spikes, noses, horns, fringe strands)."""
    return lathe(name, [(r, 0.0), (0.0, 1.0)], segments=segments, material=material, smooth=smooth,
                 start=base, end=tip)


def ring(name, r, thickness, loc, segments=16, sides=4, material="black", rot=(90, 0, 0)):
    """Low-poly torus (glasses rims, collars, halos). Default faces -Y."""
    bm = bmesh.new()
    grid = []
    for i in range(segments):
        a = 2 * math.pi * i / segments
        c = Vector((math.cos(a), math.sin(a), 0))
        row = []
        for j in range(sides):
            b = 2 * math.pi * j / sides + math.pi / sides
            row.append(bm.verts.new(c * (r + thickness * math.cos(b)) + Vector((0, 0, thickness * math.sin(b)))))
        grid.append(row)
    for i in range(segments):
        for j in range(sides):
            a, b = grid[i], grid[(i + 1) % segments]
            bm.faces.new((a[j], b[j], b[(j + 1) % sides], a[(j + 1) % sides]))
    return _finish(name, bm, material, loc, rot, True)


# --------------------------------------------------------------------------- face kit
def eye(name, loc, r=0.07, squash=(1.0, 0.55, 1.15), material="black", highlight=True, half_lid=0.0):
    """Glossy black eye + white catch-light (anime-chibi style). half_lid>0 adds a skin lid for a
    tired/sleepy look (0..1 = fraction covered). Returns the eye object."""
    e = facet(name, r, loc, squash, detail=2, jitter=0.0, material=_eye_mat(material))
    if highlight:
        hl = Vector(loc) + Vector((-r * 0.3, -r * squash[1] * 0.85, r * 0.35))   # same side on both eyes
        facet(name + "_hl", r * 0.28, hl, (1, 0.5, 1), detail=1, jitter=0, material=mat("eye_hl", "white", glow="white", strength=2))
    if half_lid > 0:
        block(name + "_lid", (r * 2.3, r * squash[1] * 2.4, r * squash[2] * 2 * half_lid),
                    Vector(loc) + Vector((0, -r * 0.1, r * squash[2] * (1 - half_lid) + 0.002)),
                    material="skin")
    return e


def _eye_mat(material):
    if isinstance(material, bpy.types.Material):
        return material
    return mat("eye_" + str(material), material, rough=0.15, spec=1.0)


def glow_rect(name, size, loc, color="warm", strength=8.0, bevel=0.01, rot=None):
    """Emissive rounded bar/square: robot eyes, mouths, screen UI, chest lights."""
    return block(name, size, loc, bevel=bevel, segments=2, smooth=True, rot=rot,
                 material=mat("glow_" + str(color), color, glow=color, strength=strength))


def glow_ball(name, r, loc, color="warm", strength=10.0):
    return ball(name, r, loc, segments=10, rings=5, material=mat("glow_" + str(color), color, glow=color, strength=strength))


# --------------------------------------------------------------------------- rig
def _view3d_ctx():
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            if a.type == "VIEW_3D":
                return {"window": w, "area": a, "region": [r for r in a.regions if r.type == "WINDOW"][0]}
    return {}


def rig(name, bones):
    """bones: list of (name, head, tail, parent_or_None, ranges, joint_r)
         ranges: {'x':(min,max), 'y':(..), 'z':(..)} in degrees, local bone axes:
                 X = pitch (nod / swing forward-back), Y = twist (turn), Z = roll/side (tilt, raise sideways)
         joint_r: radius around the pivot where touching parts are allowed to overlap.
    Bones get LIMIT_ROTATION constraints from `ranges`, so animation can't push parts into each other."""
    arm = bpy.data.armatures.new(name)
    ro = _link(bpy.data.objects.new(name, arm))
    ro.show_in_front = True
    vl = bpy.context.view_layer
    for o in vl.objects:
        o.select_set(False)
    vl.objects.active = ro
    ro.select_set(True)
    with bpy.context.temp_override(**_view3d_ctx()):
        bpy.ops.object.mode_set(mode="EDIT")
        for b in bones:
            eb = arm.edit_bones.new(b[0])
            eb.head, eb.tail = Vector(b[1]), Vector(b[2])
            d = (Vector(b[2]) - Vector(b[1])).normalized()
            eb.align_roll(Vector((0, -1, 0)) if abs(d.y) < 0.9 else Vector((0, 0, 1)))   # Z axis -> forward
            if b[3]:
                eb.parent = arm.edit_bones[b[3]]
        bpy.ops.object.mode_set(mode="OBJECT")
    for b in bones:
        pb = ro.pose.bones[b[0]]
        pb.rotation_mode = "XYZ"
        ranges = b[4] if len(b) > 4 and b[4] else {}
        pb["lpm_joint_r"] = b[5] if len(b) > 5 and b[5] else 0.15
        if ranges:
            flat = []
            for ax in "xyz":
                lo, hi = ranges.get(ax, (0, 0))
                flat += [lo, hi]
            pb["lpm_range"] = flat
            c = pb.constraints.new("LIMIT_ROTATION")
            c.owner_space = "LOCAL"
            for i, ax in enumerate("xyz"):
                setattr(c, "use_limit_" + ax, True)
                setattr(c, "min_" + ax, math.radians(flat[2 * i]))
                setattr(c, "max_" + ax, math.radians(flat[2 * i + 1]))
    return ro


def attach(rig_obj, bone, *objs):
    """Rigidly parent objects to a bone, keeping their world position."""
    vl = bpy.context.view_layer
    for o in objs:
        if isinstance(o, str):
            o = bpy.data.objects[o]
        mw = o.matrix_world.copy()
        o.parent = rig_obj
        o.parent_type = "BONE"
        o.parent_bone = bone
        vl.update()
        o.matrix_world = mw
    vl.update()


def attach_prefix(rig_obj, mapping):
    """mapping: {bone: [name prefixes]} - attach every object in the collection whose name starts with a prefix."""
    objs = [o for o in _CUR.objects if o.type == "MESH" and o.parent is None]
    for bone, prefixes in mapping.items():
        attach(rig_obj, bone, *[o for o in objs if any(o.name.startswith(p) for p in prefixes)])


# --------------------------------------------------------------------------- validation
_RAY = Vector((0.2113, 0.3511, 0.9121)).normalized()


def _inside(tree, p):
    n, o = 0, p.copy()
    for _ in range(64):
        hit = tree.ray_cast(o, _RAY)
        if hit[0] is None:
            break
        n += 1
        o = hit[0] + _RAY * 1e-5
    return n % 2 == 1


def _world(o, dg):
    ev = o.evaluated_get(dg)
    me = ev.to_mesh()
    bm = bmesh.new()
    bm.from_mesh(me)
    ev.to_mesh_clear()
    bm.transform(o.matrix_world)
    pts = [v.co.copy() for v in bm.verts] + [f.calc_center_median() for f in bm.faces]
    tree = BVHTree.FromBMesh(bm)
    lo = Vector([min(v.co[i] for v in bm.verts) for i in range(3)])
    hi = Vector([max(v.co[i] for v in bm.verts) for i in range(3)])
    bm.free()
    return tree, pts, lo, hi


def topology(o):
    """Return dict of mesh-quality stats for one object."""
    bm = bmesh.new()
    bm.from_mesh(o.data)
    st = {"tris": 0, "quads": 0, "ngons": 0, "non_manifold": 0, "loose": 0, "degenerate": 0, "inverted": False}
    for f in bm.faces:
        n = len(f.verts)
        st["tris" if n == 3 else "quads" if n == 4 else "ngons"] += 1
        if f.calc_area() < 1e-9:
            st["degenerate"] += 1
    st["non_manifold"] = sum(1 for e in bm.edges if not e.is_manifold)
    st["loose"] = sum(1 for v in bm.verts if not v.link_faces)
    if st["non_manifold"] == 0 and bm.faces:
        st["inverted"] = bm.calc_volume(signed=True) < 0
    st["tri_count"] = st["tris"] + 2 * st["quads"]
    bm.free()
    return st


def _pivots(o):
    if o.parent and o.parent_type == "BONE":
        pb = o.parent.pose.bones[o.parent_bone]
        return [(o.parent.matrix_world @ pb.head, pb.get("lpm_joint_r", 0.15))]
    return []


def _collisions(meshes, dg, moved=None):
    data = {o.name: _world(o, dg) for o in meshes}
    bad = []
    for i, a in enumerate(meshes):
        for b in meshes[i + 1:]:
            ka = (a.parent, a.parent_bone if a.parent_type == "BONE" else None)
            kb = (b.parent, b.parent_bone if b.parent_type == "BONE" else None)
            if ka == kb:
                continue                       # same rigid group: overlap is allowed (hair on head etc.)
            if moved is not None and ((a.name in moved) == (b.name in moved)):
                continue
            ta, pa, la, ha = data[a.name]
            tb, pb_, lb, hb = data[b.name]
            if any(ha[k] < lb[k] or hb[k] < la[k] for k in range(3)):
                continue
            piv = _pivots(a) + _pivots(b)
            worst = 0.0
            for pts, tree in ((pa, tb), (pb_, ta)):
                for p in pts:
                    if _inside(tree, p):
                        d = min([(p - c).length - r for c, r in piv] or [1e9])
                        worst = max(worst, d)
            if worst > 1e-3:
                bad.append((a.name, b.name, round(worst, 3)))
    return bad


def _floating(meshes, dg, tol=0.03):
    """Parts that touch nothing (floating feet, detached ears...). Same-bone groups count as one."""
    if len(meshes) < 2:
        return []
    data = {o.name: _world(o, dg) for o in meshes}
    out = []
    for a in meshes:
        best = 1e9
        for b in meshes:
            if b is a:
                continue
            tree = data[b.name][0]
            for p in data[a.name][1]:
                hit = tree.find_nearest(p)
                if hit[0] is not None:
                    best = min(best, hit[3])
                if best <= tol:
                    break
            if best <= tol:
                break
        if best > tol:
            out.append((a.name, best))
    return out


def check(collection=None, sweep=True, max_tris=12000, quiet=False):
    """Validate a character: topology of every mesh + collisions at rest and at every bone's
    rotation limits. Prints a compact report and returns True if clean."""
    col = bpy.data.collections.get(collection) if isinstance(collection, str) else (collection or _CUR)
    meshes = [o for o in col.all_objects if o.type == "MESH"]
    rigs = [o for o in col.all_objects if o.type == "ARMATURE"]
    lines, ok, total = [], True, 0
    for o in meshes:
        s = topology(o)
        total += s["tri_count"]
        probs = [k for k in ("ngons", "non_manifold", "loose", "degenerate") if s[k]]
        if s["inverted"]:
            probs.append("inverted")
        if o.parent is None and rigs:
            probs.append("not rigged")
        if probs:
            ok = False
            lines.append("  TOPO %s: %s" % (o.name, ", ".join("%s=%s" % (k, s.get(k, True)) for k in probs)))
    dg = bpy.context.evaluated_depsgraph_get()
    for name, gap in _floating(meshes, dg):
        ok = False
        lines.append("  FLOAT %s is %.3f away from every other part (attach it or close the gap)" % (name, gap))
    for a, b, d in _collisions(meshes, dg):
        ok = False
        lines.append("  REST overlap %s x %s (%.3f outside joint)" % (a, b, d))
    if sweep:
        for ro in rigs:
            for pb in ro.pose.bones:
                rng = pb.get("lpm_range")
                if not rng:
                    continue
                moved = {o.name for o in meshes if o.parent == ro and o.parent_bone in
                         [pb.name] + [c.name for c in pb.children_recursive]}
                old = pb.rotation_euler.copy()
                for i, ax in enumerate("xyz"):
                    for val in (rng[2 * i], rng[2 * i + 1]):
                        if not val:
                            continue
                        e = Euler((0, 0, 0))
                        e[i] = math.radians(val)
                        pb.rotation_euler = e
                        bpy.context.view_layer.update()
                        for a, b, d in _collisions(meshes, bpy.context.evaluated_depsgraph_get(), moved):
                            ok = False
                            lines.append("  POSE %s %s=%+d: %s x %s (%.3f)" % (pb.name, ax, val, a, b, d))
                pb.rotation_euler = old
                bpy.context.view_layer.update()
    if total > max_tris:
        lines.append("  BUDGET %d tris > %d" % (total, max_tris))
        ok = False
    print("%s %s: %d meshes, %d tris%s" % ("CLEAN" if ok else "ISSUES", col.name, len(meshes), total,
                                           "" if ok else "\n" + "\n".join(lines[:40])))
    return ok


# --------------------------------------------------------------------------- staging / preview
def stage(mood="warm", floor=True):
    """Moody studio like the references: dark world, warm key, cool rim, soft fill, optional floor."""
    sc = bpy.context.scene
    st = bpy.data.collections.get("LPM_Stage")
    if st is None:
        st = bpy.data.collections.new("LPM_Stage")
        sc.collection.children.link(st)
    for o in list(st.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    w = sc.world or bpy.data.worlds.new("World")
    sc.world = w
    try:
        w.use_nodes = True
    except Exception:
        pass
    bg = w.node_tree.nodes.get("Background")
    tone = {"warm": (0.018, 0.011, 0.008), "night": (0.006, 0.010, 0.025), "neutral": (0.02, 0.02, 0.02)}[mood]
    bg.inputs[0].default_value = (*tone, 1)
    bg.inputs[1].default_value = 1.0
    key = {"warm": (1.0, 0.62, 0.35), "night": (1.0, 0.75, 0.45), "neutral": (1, 1, 1)}[mood]
    rim = {"warm": (0.55, 0.45, 1.0), "night": (0.35, 0.6, 1.0), "neutral": (1, 1, 1)}[mood]
    for nm, col, en, loc, size in (("LPM_Key", key, 550, (-3.0, -4.0, 4.5), 3.0),
                                   ("LPM_Rim", rim, 450, (3.5, 4.0, 3.5), 2.0),
                                   ("LPM_Fill", key, 120, (4.0, -3.0, 1.5), 4.0)):
        ld = bpy.data.lights.new(nm, "AREA")
        ld.color, ld.energy, ld.size = col, en, size
        lo = bpy.data.objects.new(nm, ld)
        lo.location = loc
        lo.rotation_euler = (Vector((0, 0, 1.2)) - Vector(loc)).to_track_quat("-Z", "Y").to_euler()
        st.objects.link(lo)
    if floor:
        bm = bmesh.new()
        bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=12)
        me = bpy.data.meshes.new("LPM_Floor")
        bm.to_mesh(me)
        bm.free()
        me.materials.append(mat("floor", (0.03, 0.022, 0.018) if mood == "warm" else (0.02, 0.025, 0.04), rough=0.9))
        st.objects.link(bpy.data.objects.new("LPM_Floor", me))
    return st


def preview(path, collection=None, res=640, azimuth=-25, elevation=8, zoom=1.0, samples=16):
    """Render a quick EEVEE still of the character to `path` (PNG) and return the path.
    azimuth 0 = straight front; negative turns the camera to the character's right side."""
    sc = bpy.context.scene
    col = bpy.data.collections.get(collection) if isinstance(collection, str) else (collection or _CUR)
    pts = []
    for o in col.all_objects:
        if o.type == "MESH":
            pts += [o.matrix_world @ Vector(c) for c in o.bound_box]
    lo = Vector([min(p[i] for p in pts) for i in range(3)])
    hi = Vector([max(p[i] for p in pts) for i in range(3)])
    ctr, size = (lo + hi) / 2, (hi - lo).length
    cam = bpy.data.objects.get("LPM_Cam")
    if cam is None:
        cam = bpy.data.objects.new("LPM_Cam", bpy.data.cameras.new("LPM_Cam"))
        st = bpy.data.collections.get("LPM_Stage") or sc.collection
        st.objects.link(cam)
    cam.data.lens = 50
    fov = cam.data.angle
    dist = size / (2 * math.tan(fov / 2)) * 1.05 / zoom
    az, el = math.radians(azimuth), math.radians(elevation)
    d = Vector((math.sin(az) * math.cos(el), -math.cos(az) * math.cos(el), math.sin(el)))
    cam.location = ctr + d * dist
    cam.rotation_euler = (-d).to_track_quat("-Z", "Y").to_euler()
    sc.camera = cam
    r = sc.render
    r.engine = "BLENDER_EEVEE"
    r.resolution_x = r.resolution_y = res
    r.resolution_percentage = 100
    r.film_transparent = False
    try:
        sc.eevee.taa_render_samples = samples
    except Exception:
        pass
    r.image_settings.file_format = "PNG"
    r.filepath = path
    try:
        sc.view_settings.view_transform = "Standard"
        sc.view_settings.look = "None"
    except Exception:
        pass
    keep = set(col.all_objects) | set(bpy.data.collections["LPM_Stage"].all_objects if "LPM_Stage" in bpy.data.collections else [])
    hidden = [o for o in sc.objects if o not in keep and not o.hide_render]
    for o in hidden:                      # render only this character + the stage
        o.hide_render = True
    try:
        bpy.ops.render.render(write_still=True)
    finally:
        for o in hidden:
            o.hide_render = False
    return path


# --------------------------------------------------------------------------- animation helpers
def key_pose(ro, frame, **bones):
    """key_pose(rig, 12, head=(10,0,0), **{'arm.L': (30,0,0)}) - euler degrees per bone, keyed."""
    for bn, rot in bones.items():
        pb = ro.pose.bones[bn]
        pb.rotation_euler = Euler([math.radians(a) for a in rot])
        pb.keyframe_insert("rotation_euler", frame=frame)


def idle(ro, frames=48, amount=0.6):
    """Generic looping idle that stays inside every bone's limits (scaled by amount)."""
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, frames
    for pb in ro.pose.bones:
        rng = pb.get("lpm_range")
        if not rng:
            continue
        for k, f in enumerate((1, frames // 4, frames // 2, 3 * frames // 4, frames)):
            s = (0, 1, 0, -1, 0)[k]
            e = Euler([math.radians(s * amount * min(abs(rng[2 * i]), abs(rng[2 * i + 1])) * (0.5 if i == 1 else 1))
                       for i in range(3)])
            if not any(e):
                e = Euler((0, 0, 0))
            pb.rotation_euler = e
            pb.keyframe_insert("rotation_euler", frame=f)
    return ro
