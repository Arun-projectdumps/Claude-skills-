---
name: lowpolymodel
description: Build stylized low-poly 3D characters in the user's running Blender (faceted chibi humans with big heads and hoodies, smooth toy robots with glowing screen faces and antennas, faceted mascot blobs, and new improvised designs in that style). Clean geometry (tris/quads only, closed manifold meshes, no n-gons), small token cost via a helper library, and rigid bone rigs with rotation limits that are collision-tested so small animations never break or self-intersect. Use when the user runs /modelchar or asks for a low-poly character, mascot, bot or buddy model in Blender.
---

# lowpolymodel

Builds characters in the style of the user's reference reels (@agentpoly, canwebuildthis, agentcinder):
moody, warm-lit, low-poly toys. Read `references/style-guide.md` once per session before designing.

## How it talks to Blender
Blender runs with the MCP for Blender add-on (formerly BlenderMCP) on `127.0.0.1:9876`. Every call goes through:

```bash
python3 ~/.claude/skills/lowpolymodel/scripts/bsend.py <file.py | -c "code">
```

`bsend.py` auto-loads `scripts/lpm.py` into Blender as module `lpm` (reloads when the file changes),
so every snippet just starts with `import lpm`. If the connection is refused, ask the user to open
Blender and start the add-on server (N-panel > MCP for Blender tab > Connect to MCP server; older versions call it
BlenderMCP > Connect). Also check the "Interface: MCP for Blender" add-on is enabled in Preferences.

## Workflow (keep it cheap)
1. **Pick the closest example** in `examples/` (`chibi.py`, `bot.py`, `buddy.py`), read only that one.
2. **Write ONE build script** to the scratchpad: copy the example, change the PARAMS and the parts that
   make this character new. Don't rewrite lpm functions inline; call them. Typical script: 40-90 lines.
3. Run it: `bsend.py build.py` prints `CLEAN <name>: N meshes, T tris` or a list of issues.
4. Fix only what the report names (move/resize that part, adjust that bone's range), rerun.
5. Look once: `bsend.py -c "import lpm; lpm.stage(); print(lpm.preview('<scratchpad>/p.png', '<Name>', res=480))"`
   then Read the PNG. Use `azimuth=0` for a front view. Fix proportions if needed. 1-2 preview rounds max.
6. Optional: `lpm.idle(bpy.data.objects['<Name>_rig'])` keys a looping idle that stays in limits.
7. Tell the user: what was built, tri count, bones and their ranges, that `check()` passed.
   Don't save the .blend unless asked.

Improvise, don't clone: the examples are starting points. Change silhouettes (head shape, hair style,
body width, lobes, ears, accessories like headphones, scarf, backpack, glasses, hats), palettes, and
expressions per request. New prop/part = combine primitives below.

## lpm API (all sizes in meters, character faces -Y, +X = character's left = `.L`)
| call | use |
|---|---|
| `begin(name)` | start/rebuild a character collection (wipes its old objects) |
| `facet(name, r, loc, scale, detail=1..3, jitter, material, flatten_front)` | faceted low-poly sphere: heads, hair caps, hands, lobes, rocks |
| `block(name, size, loc, bevel, segments, material, smooth, rot)` | boxes; `bevel+smooth=True` = soft toy look |
| `limb(name, start, end, r, r2, segments, material, smooth)` | capsule between two points; **start = joint pivot** |
| `spike(name, base, tip, r, segments=4)` | pyramids/cones: hair strands, noses, horns, ears |
| `lathe(name, [(r,z)...], loc or start/end, segments)` | any round profile: necks, antenna stalks, bottles, hats |
| `ball(name, r, loc, segments, rings)` | smooth sphere |
| `ring(name, r, thickness, loc)` | torus: glasses rims, collars, halos |
| `eye(name, loc, r, half_lid)` | glossy black eye + catch-light, optional sleepy lid |
| `glow_rect / glow_ball(name, ..., color)` | emissive bars/dots: robot eyes, mouths, bulbs, screen UI |
| `mat(name, color, rough, glow=, strength=)` | material; colors from `PALETTE`/`GLOW` names or RGB |
| `rig(name, [(bone, head, tail, parent, {'x':(lo,hi),...}, joint_r)])` | armature + LIMIT_ROTATION per bone |
| `attach(rig, bone, *objs)` / `attach_prefix(rig, {bone: [prefixes]})` | rigid bone parenting |
| `check()` | topology + floating parts + collision sweep at every bone limit |
| `stage(mood='warm'/'night'/'neutral')`, `preview(path, name, res, azimuth)` | lights/floor + quick EEVEE still |
| `key_pose(rig, frame, **{bone: (x,y,z)})`, `idle(rig)` | animation keys |
| `remove(*names)`, `topology(obj)` | utilities |

Bone axes (roll is set so local Z points forward): **X = nod / swing forward-back, Y = twist/turn,
Z = tilt / raise sideways**. For `arm.L` negative Z swings the arm *into* the body; for `arm.R` positive Z does.

## Geometry rules (what keeps models clean)
- Only build with lpm primitives. They are closed meshes, tris and quads only, and any n-gon is
  triangulated automatically. Never boolean, never extrude open shells, and never use planes for body parts.
- Overlapping parts is how detail gets added, and it is fine **within one bone** (hair on head, eyes on face, pocket on
  torso). Don't try to merge them into one mesh.
- Budget: hero character 800-3000 tris. Faceted look = `facet(detail=2)` (80 tris) for heads/bodies,
  `detail=1` for hands, ears, feet. Smooth look = `block(bevel, segments=3-4, smooth=True)` and `ball`/
  `limb(segments=10, smooth=True)`. Don't add subdivision modifiers.
- Faceted style = flat shading (default). Smooth style = `smooth=True` (beveled blocks get weighted
  normals automatically so flat faces stay flat).

## Animation-safe rules (why nothing breaks when it moves)
- Every moving part is a **separate rigid mesh parented to a bone**, with no skin weights, so nothing ever stretches.
- **Joint = round end centered on the pivot.** `limb(start=pivot)` puts the capsule's hemisphere on the
  pivot, so rotating never opens a gap. Put a `ball` on the parent part at the joint for robots.
- Keep **clearance** between parts on different bones away from joints: limb surface ≥ 0.02 from torso
  sides (e.g. arm center x ≥ torso half-width + arm radius + 0.02). Legs: gap between thighs.
- Give every bone a **range** and a `joint_r` (overlap allowed only within joint_r of the pivot). The
  rig's LIMIT_ROTATION constraints stop animators from going past what `check()` tested.
- If `check()` reports `POSE bone axis=val: A x B`, either shrink that range, move the part out, or put
  both parts on the same bone if they should move together.

## Check report legend
`TOPO` n-gons/non-manifold/loose/degenerate/inverted or unrigged mesh · `FLOAT` part touches nothing ·
`REST` parts on different bones overlap away from a joint · `POSE` collision at a limit · `BUDGET` too many tris.
Only report done when the last line is `CLEAN`.
