# lpf channels (for custom work only)

All `play()` overrides are **peak values**: the value held during the expression. The engine keys
neutral → peak (ramp) → peak with secondary motion (life) → neutral.

| channel | neutral | meaning | drives |
|---|---|---|---|
| head, spine, armL, armR, legL, legR, antenna | (0,0,0) | euler degrees, clamped to the rig's lpm ranges | existing bones |
| hop | 0 | root lift in meters | root bone location |
| eye | 1 | eye size (both) | face.eye.L/R scale |
| eyeL / eyeR | 1 | extra per-eye size multiplier | " |
| open | 1 | eyelid opening, 0.06 = shut (blinks multiply this) | eye bone scale Z |
| look | (0,0) | eye shift (x, z) in eye radii | eye bone location |
| happy | 0 | 1 = swap eyes for ^ ^ arcs (pair it with open≈0.1) | face.hap.* + eye visibility |
| lid | 0 | skin lid coverage from the top, 0..1 | face.lid.* scale Z |
| lid_tilt | 0 | degrees, + = outer corners down (sad), - = angry | face.lid.* rot |
| brow | (0,0) | (raise°, worry°): raise slides the brow over the skull; worry + = inner ends up | face.brow.* (pivot = head center) |
| browL / browR | (0,0) | added per side | " |
| smile frown mopen o wide | 0 | mouth shape keys (0..1.6, they add together) | mouth mesh shape keys |
| blush shy sweat tear shock q spark | 0 | FX size 0..1 (hidden at 0) | face.cheek/shy, fx.* bones |
| *_m (sweat_m, tear_m, shy_m, q_m, spark_m, shock_m) | 0 | FX motion: slide / wobble / bob / spin / pulse | same bones |

Life items in `PRESETS[...]['life']` (lpf.py): `('blink', every)`, `('osc', ch, idx|None, amp, period[, phase])`,
`('jit', ch, idx|None, amp, step)`, `('talk', amount)`, `('hop', height, count)`, `('slide', fx)`,
`('at', frac, {ch: value})`. Preset keys: `len`, `ramp`, `overshoot`, `reach` (uses the fitted hands-on-face pose
via `armL="REACH"`), `peak`, `life`.

Face rig created by `setup()` (all children of the head bone, which is whatever bone the eyes were on):
`face.eye.L/R`, `face.lid.L/R`, `face.hap.L/R`, `face.brow.L/R`, `face.mouth`, `face.cheek.L/R`, `face.shy.L/R`,
`fx.tear.L/R`, `fx.sweat`, `fx.shock.L/R`, `fx.q`, `fx.spark0..2`. The FX meshes live in collection `<Name>_FX`.
`setup` info is stored as JSON in `rig["lpf"]` (eye centers and radii, brow data, fitted reach angles).
Part names it looks for: `<P>eyeL/R` (required; `<P>eyeL_*` like `_hl` follows the eye), `<P>browL/R`, `<P>mouth`,
`hand` inside the arm meshes (for the reach fit).

Bone axes (lpm convention): body bones X = nod/swing forward (+), Y = twist, Z = tilt or raise sideways.
Face bones point forward with local Z = up, so scale Z squashes vertically.
