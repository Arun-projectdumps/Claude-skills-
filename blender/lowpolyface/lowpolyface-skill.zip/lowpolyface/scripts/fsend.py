#!/usr/bin/env python3
"""Run Python in the running Blender with both `lpm` (lowpolymodel) and `lpf` (lowpolyface) loaded.

Usage:
  fsend.py -c "import lpf; lpf.play('GokuBoy', 'happy')"
  fsend.py file.py
Modules are (re)loaded automatically whenever their source file changes.
"""
import os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
LPM_DIR = os.path.expanduser("~/.claude/skills/lowpolymodel/scripts")
sys.path.insert(0, LPM_DIR)
import bsend  # noqa: E402

MODS = (("lpm", os.path.join(LPM_DIR, "lpm.py")), ("lpf", os.path.join(HERE, "lpf.py")))


def _loader(mod, path):
    with open(path) as f:
        src = f.read()
    return (
        "import sys, types\n"
        "m = types.ModuleType(%r); m.__file__ = %r\n"
        "sys.modules[%r] = m\n"
        "exec(compile(%r, %r, 'exec'), m.__dict__)\n"
        "m._MTIME = %r\n"
    ) % (mod, path, mod, src, os.path.basename(path), os.path.getmtime(path))


def ensure():
    chk = "import sys\nprint(','.join(n for n, t in %r if getattr(sys.modules.get(n), '_MTIME', 0) != t), end='')\n" % (
        [(n, os.path.getmtime(p)) for n, p in MODS],)
    r = bsend.send(chk)
    need = str(r.get("result", {}).get("result", "") if isinstance(r.get("result"), dict) else r.get("result", ""))
    for n, p in MODS:
        if n in need.split(",") or (n == "lpf" and "lpm" in need.split(",")):
            bsend.run(_loader(n, p))


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    ensure()
    if argv[0] == "-c":
        return bsend.run(argv[1])
    rc = 0
    for p in argv:
        with open(p) as f:
            rc |= bsend.run(f.read())
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
