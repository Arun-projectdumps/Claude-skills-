"""lpf - facial + gesture animation for lowpolymodel (lpm) characters. Runs INSIDE Blender.

How a face moves without deforming anything
  * setup() adds small FACE BONES under the head bone and re-parents the existing rigid parts:
      face.eye.L/R   (eye + catch-light + old lid)  pivot = eye center  -> scale (size, blink), loc (look)
      face.brow.L/R  pivot = HEAD CENTER, tail = brow -> rot X slides the brow over the skull (raise),
                     rot Y spins it about its own center (worry / anger tilt)
      face.mouth     mouth mesh gets shape keys: smile, frown, open, o, wide (only the tiny mouth deforms)
      face.lid.L/R   skin lid that drops from the eye top (sad / sleepy), scale Z = coverage
      face.hap.L/R   ^ ^ arcs that replace the eyes (joy)
      face.cheek / face.shy  blush disc and /// lines
      fx.*           sweat drop, tears, shock lines, '?' mark, sparkles
  * Extras live in collection <Name>_FX (hidden unless keyed), so lpm.check() on the character stays CLEAN.
  * Body gestures use the existing bones and stay inside their LIMIT_ROTATION ranges. The one exception is
    the auto-fitted 'hands on cheeks' reach pose; its constraint is muted only for that clip and the
    pose is collision-tested at setup.

API
  setup(name, rebuild=False)            once per character (idempotent)
  play(name, preset, **opts)            key a preset (replaces the old animation unless start=/clear=False)
  check(name)                           collision test across the keyed frames
  sheet(name, path, frames=None)        contact sheet PNG of several frames (one image to look at)
  reset(name), presets()
"""
VERSION = "1.0"

import bpy, bmesh, math, random, json, os
from mathutils import Vector as V, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
import lpm

# --------------------------------------------------------------------------- presets
# peak: the held expression. Channels:
#   body (deg xyz): head spine armL armR legL legR antenna     hop: root lift (m)
#   eyes: eye (size x), eyeL/eyeR (extra size x), open (0 shut..1), look (x,z in eye radii), happy (0/1 = ^ ^)
#   lid (0..1 coverage), lid_tilt (deg, + = outer corners down)
#   brow (raise deg, worry deg + = inner ends up / - = angry), browL / browR (added per side)
#   mouth shape keys: smile frown mopen o wide
#   fx (0..1): blush shy sweat tear shock q spark
# life: secondary motion during the hold
#   ('blink', every) ('osc', ch, idx|None, amp, period[, phase]) ('jit', ch, idx|None, amp, step)
#   ('talk', amount) ('hop', height, count) ('slide', fx) ('at', frac, {ch: value})
PRESETS = {
    # ---- emotions
    "happy": dict(len=72, peak=dict(smile=1.0, open=0.82, brow=(5, 0), head=(-4, 0, 7), blush=0.35),
                  life=[("blink", 40), ("osc", "head", 2, 4, 36), ("osc", "head", 0, 2, 24)]),
    "joy": dict(len=72, ramp=6, peak=dict(happy=1, open=0.1, smile=1.0, mopen=0.6, wide=0.25, brow=(9, 0), head=(-10, 0, 0),
                                          armL=(25, 0, 52), armR=(25, 0, -52), blush=0.6, spark=1),
                life=[("hop", 0.09, 2), ("osc", "armL", 2, 6, 12), ("osc", "armR", 2, -6, 12),
                      ("osc", "spark_m", None, 1, 24)]),
    "cry": dict(len=120, ramp=12, peak=dict(brow=(-2, 26), lid=0.5, lid_tilt=16, look=(0, -0.2), frown=1.25, mopen=0.35,
                                            wide=0.2, open=0.9, head=(12, 0, 0), spine=(8, 0, 0), tear=1.15),
                life=[("drip", "tear", 30), ("osc", "spine", 0, 2.5, 10), ("osc", "head", 0, 2, 10),
                      ("osc", "mopen", None, 0.25, 10), ("blink", 40)]),
    "talk_gesture": dict(len=120, ramp=8, peak=dict(smile=0.25, brow=(3, 0), armL=(22, 0, 10), armR=(30, 0, -14)),
                         life=[("talk", 1.0), ("blink", 46), ("osc", "head", 2, 3, 48), ("osc", "head", 0, 2.5, 30),
                               ("jit", "brow", 0, 3, 12), ("osc", "armL", 0, 16, 40), ("osc", "armR", 0, -14, 32),
                               ("osc", "armL", 2, 7, 52), ("osc", "armR", 2, -6, 44), ("osc", "spine", 1, 4, 60)]),
    "sad": dict(len=96, ramp=14, peak=dict(brow=(-2, 20), lid=0.42, lid_tilt=14, look=(0, -0.25), frown=1.0, open=0.95,
                                           head=(9, 0, 5), spine=(7, 0, 0), tear=1),
                life=[("blink", 55), ("osc", "head", 0, 1.5, 48), ("slide", "tear")]),
    "scared": dict(len=84, ramp=6, reach=True,
                   peak=dict(brow=(7, 24), eye=0.9, open=1.05, frown=0.6, wide=0.5, mopen=0.3,
                             head=(-4, 0, 0), spine=(-5, 0, 0), armL="REACH", armR="REACH", sweat=1),
                   life=[("blink", 28), ("jit", "spine", 2, 1.4, 2), ("jit", "look", 0, 0.12, 3), ("slide", "sweat")]),
    "shocked": dict(len=72, ramp=4, overshoot=1.18,
                    peak=dict(eye=1.32, open=1.0, brow=(15, 0), o=1.0, mopen=0.3, head=(-10, 0, 0), spine=(-8, 0, 0),
                              armL=(15, 0, 28), armR=(15, 0, -28), shock=1),
                    life=[("osc", "shock_m", None, 1, 8), ("at", 0.85, {"open": 0.06})]),
    "curious": dict(len=84, peak=dict(head=(-3, 8, 14), spine=(6, 0, 0), browL=(11, -4), browR=(-3, -6), eyeL=1.12,
                                      look=(0.3, 0.2), o=0.35, q=1),
                    life=[("blink", 45), ("osc", "head", 2, 3, 40), ("osc", "q_m", None, 1, 24)]),
    "shy": dict(len=96, ramp=12, peak=dict(head=(7, -14, -9), spine=(0, -8, 0), look=(-0.3, -0.15), blush=1, shy=1,
                                           smile=0.45, brow=(2, 10), open=0.85, armL=(14, 0, 0), armR=(14, 0, 0)),
                life=[("blink", 34), ("osc", "shy_m", None, 1, 16), ("osc", "armL", 0, 5, 30), ("osc", "armR", 0, -5, 30),
                      ("osc", "look", 0, 0.25, 48)]),
    "angry": dict(len=72, ramp=6, peak=dict(brow=(-4, -24), lid=0.22, lid_tilt=-14, frown=0.9, wide=0.35, head=(8, 0, 0),
                                            spine=(5, 0, 0), armL=(10, 0, 4), armR=(10, 0, -4)),
                  life=[("blink", 50), ("jit", "head", 1, 1.0, 3)]),
    "sleepy": dict(len=120, ramp=16, peak=dict(lid=0.55, open=0.9, brow=(-3, 5), head=(12, 0, 6), mopen=0.12),
                   life=[("osc", "head", 0, 6, 60), ("at", 0.5, {"lid": 0.9}), ("blink", 70)]),
    # ---- basics
    "blink": dict(len=96, ramp=1, peak=dict(), life=[("blink", 30), ("jit", "look", 0, 0.15, 24)]),
    "talk": dict(len=120, ramp=4, peak=dict(smile=0.25, brow=(3, 0)),
                 life=[("talk", 1.0), ("blink", 46), ("osc", "head", 2, 3, 48), ("osc", "head", 0, 2.5, 30),
                       ("jit", "brow", 0, 3, 12)]),
    "nod_yes": dict(len=48, ramp=4, peak=dict(), life=[("osc", "head", 0, 13, 16)]),
    "nod_no": dict(len=60, ramp=4, peak=dict(), life=[("osc", "head", 1, 22, 20)]),
    "nod_yes_smile": dict(len=56, ramp=6, peak=dict(smile=1.0, open=0.8, brow=(5, 0), blush=0.3),
                          life=[("osc", "head", 0, 12, 16), ("blink", 40)]),
    "nod_no_sad": dict(len=84, ramp=12, peak=dict(brow=(-2, 18), lid=0.35, lid_tilt=12, frown=0.9, head=(10, 0, 0),
                                                  look=(0, -0.2)),
                       life=[("osc", "head", 1, 16, 28), ("blink", 60)]),
}
ALIASES = {"joyful": "joy", "excited": "joy", "glad": "happy", "smile": "happy", "afraid": "scared", "fear": "scared",
           "surprised": "shocked", "surprise": "shocked", "wow": "shocked", "embarrassed": "shy", "blush": "shy",
           "upset": "sad", "cry": "cry", "crying": "cry", "sob": "cry", "gesture": "talk_gesture", "talk_arms": "talk_gesture", "mad": "angry", "tired": "sleepy", "speak": "talk", "talking": "talk",
           "yes": "nod_yes", "no": "nod_no", "nod": "nod_yes", "shake": "nod_no", "idle": "blink",
           "wonder": "curious", "confused": "curious"}

NEUTRAL = dict(head=(0, 0, 0), spine=(0, 0, 0), armL=(0, 0, 0), armR=(0, 0, 0), legL=(0, 0, 0), legR=(0, 0, 0),
               antenna=(0, 0, 0), hop=0.0, eye=1.0, eyeL=1.0, eyeR=1.0, open=1.0, look=(0, 0), happy=0.0, lid=0.0,
               lid_tilt=0.0, brow=(0, 0), browL=(0, 0), browR=(0, 0), smile=0.0, frown=0.0, mopen=0.0, o=0.0,
               wide=0.0, blush=0.0, shy=0.0, sweat=0.0, tear=0.0, shock=0.0, q=0.0, spark=0.0,
               blush_m=0.0, shy_m=0.0, sweat_m=0.0, tear_m=0.0, shock_m=0.0, q_m=0.0, spark_m=0.0)
BODY = ("head", "spine", "armL", "armR", "legL", "legR", "antenna")
BONE_OF = {"spine": "spine", "armL": "arm.L", "armR": "arm.R", "legL": "leg.L", "legR": "leg.R", "antenna": "antenna"}
MOUTH = ("smile", "frown", "mopen", "o", "wide")
FX = ("blush", "shy", "sweat", "tear", "shock", "q", "spark")
GROUPS = {"arms": ("armL", "armR"), "body": ("head", "spine", "armL", "armR", "legL", "legR", "hop"),
          "fx": FX + ("shy_m", "sweat_m", "tear_m", "shock_m", "q_m", "spark_m"), "mouth": MOUTH,
          "brows": ("brow", "browL", "browR"), "eyes": ("eye", "eyeL", "eyeR", "open", "look", "happy", "lid", "lid_tilt")}


_CUSTOM = os.path.join(os.path.dirname(os.path.abspath(globals().get("__file__", "."))), "..", "custom_presets.json")


def _load_custom():
    try:
        with open(_CUSTOM) as f:
            return json.load(f)
    except Exception:
        return {}


def presets():
    return sorted(set(PRESETS) | set(_load_custom()))


def save_preset(new_name, base, **opts):
    """Save a tweaked preset (base preset + any play() options/overrides) for later sessions.
    Saving under a built-in name replaces that built-in for this user."""
    c = _load_custom()
    b = _resolve(base)
    if b in c:                                   # stacking on another custom preset
        merged = dict(c[b]["opts"])
        merged.update(opts)
        opts, b = merged, c[b]["base"]
    c[new_name.lower()] = dict(base=b, opts={k: (list(v) if isinstance(v, tuple) else v) for k, v in opts.items()})
    with open(_CUSTOM, "w") as f:
        json.dump(c, f, indent=1)
    print("saved preset %r = %s + %s" % (new_name, b, opts))


def seq(name, clips, start=1):
    """Chain clips: seq('Hero', ['talk', ('nod_yes', {'speed': 1.2}), 'happy']) -> last frame."""
    f = start
    for i, c in enumerate(clips):
        n, o = (c, {}) if isinstance(c, str) else c
        f = play(name, n, start=f if i == 0 else f + 1, clear=(i == 0), **o)
    bpy.context.scene.frame_start = start
    return f


# --------------------------------------------------------------------------- discovery
def _rig(name):
    if isinstance(name, bpy.types.Object):
        return name
    col = bpy.data.collections.get(name)
    if col:
        for o in col.all_objects:
            if o.type == "ARMATURE":
                return o
    return bpy.data.objects.get(name) or bpy.data.objects.get(name + "_rig")


def _char_col(ro):
    return ro.users_collection[0]


def _fx_col(ro, create=True):
    n = _char_col(ro).name + "_FX"
    c = bpy.data.collections.get(n)
    if c is None and create:
        c = bpy.data.collections.new(n)
        bpy.context.scene.collection.children.link(c)
    return c


def _info(ro):
    return json.loads(ro.get("lpf", "{}"))


def _meshes(ro, bones=None):
    out = []
    for c in (_char_col(ro), _fx_col(ro, False)):
        if c:
            out += [o for o in c.all_objects if o.type == "MESH" and o.parent == ro and
                    (bones is None or o.parent_bone in bones)]
    return out


def _world_bvh(objs):
    verts, polys = [], []
    for o in objs:
        mw = o.matrix_world
        base = len(verts)
        verts += [mw @ v.co for v in o.data.vertices]
        polys += [[base + i for i in p.vertices] for p in o.data.polygons]
    return BVHTree.FromPolygons(verts, polys) if polys else None


def _bbox(objs):
    pts = [o.matrix_world @ V(c) for o in objs for c in o.bound_box]
    lo = V([min(p[i] for p in pts) for i in range(3)])
    hi = V([max(p[i] for p in pts) for i in range(3)])
    return lo, hi


def _first_hit(tree, origin, d):
    hit = tree.ray_cast(origin, d)
    return (hit[0], hit[1]) if hit[0] is not None else (None, None)


def _anchor(tree, center, d, push, front=0.0):
    """Silhouette point seen from direction d (aimed at center), pushed out along d, then moved
    `front` along -Y. Use d with y=0 so head-wide fx sit OUTSIDE the front silhouette (works for
    round heads and box heads alike)."""
    d = V(d).normalized()
    p, n = _first_hit(tree, center + d * 4.0, -d)
    if p is None:
        p = center + d * 0.5
    return p + d * push + V((0, -front, 0))


# --------------------------------------------------------------------------- bones
def _add_bones(ro, specs):
    """specs: [(name, head, tail, parent, up_vector, joint_r)]"""
    vl = bpy.context.view_layer
    for o in vl.objects:
        o.select_set(False)
    vl.objects.active = ro
    ro.select_set(True)
    with bpy.context.temp_override(**lpm._view3d_ctx()):
        bpy.ops.object.mode_set(mode="EDIT")
        eb = ro.data.edit_bones
        Mi = ro.matrix_world.inverted()
        for nm, h, t, par, up, jr in specs:
            b = eb.get(nm) or eb.new(nm)
            b.head, b.tail = Mi @ V(h), Mi @ V(t)
            b.align_roll(Mi.to_3x3() @ V(up))
            b.parent = eb[par]
            b.use_deform = False
        bpy.ops.object.mode_set(mode="OBJECT")
    for nm, h, t, par, up, jr in specs:
        pb = ro.pose.bones[nm]
        pb.rotation_mode = "XYZ"
        pb["lpm_joint_r"] = jr
        pb["lpf"] = 1


def _del_face_bones(ro):
    names = [b.name for b in ro.data.bones if b.name.startswith(("face.", "fx."))]
    if not names:
        return
    vl = bpy.context.view_layer
    vl.objects.active = ro
    with bpy.context.temp_override(**lpm._view3d_ctx()):
        bpy.ops.object.mode_set(mode="EDIT")
        for n in names:
            eb = ro.data.edit_bones.get(n)
            if eb:
                ro.data.edit_bones.remove(eb)
        bpy.ops.object.mode_set(mode="OBJECT")


def _neutral_pose(ro):
    for pb in ro.pose.bones:
        pb.rotation_euler = (0, 0, 0)
        pb.location = (0, 0, 0)
        pb.scale = (1, 1, 1)
    bpy.context.view_layer.update()


def _orient(o, pos, normal, spin=0.0):
    """Place object o at pos with its -Y (front) facing `normal`, spun `spin` deg about that normal."""
    q = V((0, -1, 0)).rotation_difference(V(normal).normalized())
    m = q.to_matrix().to_4x4() @ Matrix.Rotation(math.radians(spin), 4, "Y")
    o.matrix_world = Matrix.Translation(pos) @ m


def _fxmat(name, color, glow=0.0, rough=0.4):
    m = lpm.mat("fx_" + name, color, rough=rough, glow=color if glow else None, strength=glow)
    return m


# --------------------------------------------------------------------------- setup
def setup(name, rebuild=False, quiet=False):
    """Add face bones, shape keys and FX parts to an lpm character. Safe to call again."""
    ro = _rig(name)
    if ro is None:
        raise ValueError("no rig for %r" % name)
    if ro.get("lpf") and not rebuild:
        return _info(ro)
    reset(ro, keep_setup=True) if ro.get("lpf") else None
    P = ro.name[:-3] if ro.name.endswith("_rig") else ro.name + "_"
    Mi = ro.matrix_world.inverted()
    col = _char_col(ro)
    # undo a previous setup: give parts back to their old bones, drop fx, bones, shape keys
    for o in col.all_objects:
        if o.type == "MESH" and o.parent == ro and o.get("lpf_bone"):
            lpm.attach(ro, o["lpf_bone"], o)
            del o["lpf_bone"]
    fxc = _fx_col(ro)
    for o in list(fxc.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    _del_face_bones(ro)
    _neutral_pose(ro)
    for c in ro.pose.bones:
        for k in c.constraints:
            k.influence = 1.0
    get = lambda n: bpy.data.objects.get(P + n)
    eyes = {s: get("eye" + s) for s in "LR"}
    if not all(eyes.values()):
        cand = [o for o in col.all_objects if o.type == "MESH" and o.name.startswith(P + "eye") and "_" not in o.name[len(P):]]
        for s in "LR":
            eyes[s] = eyes[s] or next((o for o in cand if o.name[len(P) + 3:].startswith(s)), None)
    E = eyes["L"] or eyes["R"]
    if E is None:
        raise ValueError("no eyes found (expected objects %seyeL / %seyeR)" % (P, P))
    hb = E.parent_bone
    rot = lambda v: v
    head_meshes = [o for o in col.all_objects if o.type == "MESH" and o.parent == ro and o.parent_bone == hb]
    # face surface = the head-bone mesh whose surface passes closest to the eye center ('head' preferred)
    ec = E.matrix_world.translation
    cands = []
    for o in head_meshes:
        if o.name.startswith(P + "eye") or o.name.startswith(P + "brow") or o.name == P + "mouth":
            continue
        t = _world_bvh([o])
        h = t.find_nearest(ec) if t else (None,)
        if h[0] is not None:
            cands.append((h[3] - (0.05 if "head" in o.name[len(P):].lower() else 0), o))
    face = min(cands, key=lambda x: x[0])[1] if cands else head_meshes[0]
    face_tree = _world_bvh([face])
    lo, hi = _bbox([face])
    hc = (lo + hi) / 2
    fmat = face.data.materials[0] if face.data.materials else lpm.mat("skin")
    emat = E.data.materials[0] if E.data.materials else lpm.mat("black")
    bsdf = emat.node_tree.nodes.get("Principled BSDF") if emat.node_tree else None
    if not (bsdf and bsdf.inputs["Emission Strength"].default_value > 0):
        emat = _fxmat("arc", (0.01, 0.008, 0.008), rough=0.7)
    skin_like = face.data.materials and any(k in face.data.materials[0].name for k in ("skin",))
    info = dict(P=P, head=hb, face=face.name, eyes={}, brows={}, mouth=None, reach=None)
    specs, parts = [], []           # parts: (obj, bone)
    up = V((0, 0, 1))
    fwd = V((0, -1, 0))
    lpm._CUR = fxc
    for s, sg in (("L", 1), ("R", -1)):
        e = eyes[s]
        if not e:
            continue
        c = e.matrix_world.translation.copy()
        rx, ry, rz = e.dimensions.x / 2, e.dimensions.y / 2, e.dimensions.z / 2
        info["eyes"][s] = dict(c=list(Mi @ c), r=[rx, ry, rz])
        specs.append(("face.eye." + s, c, c + fwd * rx, hb, up, max(rx, rz) * 2.2))
        for o in col.all_objects:
            if o.type == "MESH" and (o == e or o.name.startswith(e.name + "_")):
                parts.append((o, "face.eye." + s))
        # lid: skin block hanging from the eye top, scale Z = coverage
        top = c + V((0, 0, rz + 0.004))
        specs.append(("face.lid." + s, top, top + fwd * rx, hb, up, max(rx, rz) * 2.4))
        lid = lpm.block(P + "lid" + s, (rx * 2.5, ry * 2.4, rz * 2.1), top + V((0, -ry * 0.25, -rz * 1.05)),
                        bevel=min(rx, rz) * 0.25, segments=1, material=fmat)
        parts.append((lid, "face.lid." + s))
        # happy ^ arcs in front of the eye
        fp = c + V((0, -ry * 0.8, 0))
        specs.append(("face.hap." + s, fp, fp + fwd * rx, hb, up, max(rx, rz) * 2.4))
        tr = max(min(rx, rz) * 0.2, 0.012)
        a, b_, d = fp + V((-rx * 0.85, 0, -rz * 0.15)), fp + V((0, -ry * 0.1, rz * 0.4)), fp + V((rx * 0.85, 0, -rz * 0.15))
        parts.append((lpm.limb(P + "hap%s1" % s, b_, a, tr, segments=6, material=emat), "face.hap." + s))
        parts.append((lpm.limb(P + "hap%s2" % s, b_, d, tr, segments=6, material=emat), "face.hap." + s))
        # cheek blush + /// lines
        o_ = V((c.x + sg * rx * 0.35, c.y - 1.0, c.z - rz * 1.75))
        h = face_tree.ray_cast(o_, V((0, 1, 0)))
        cp, cn = (h[0], h[1]) if h[0] is not None else (c + V((0, 0, -rz * 1.6)), fwd)
        cn = (cn + fwd).normalized()
        specs.append(("face.cheek." + s, cp, cp + cn * rx, hb, up, rx * 3))
        bl = lpm.facet(P + "blush" + s, rx * 0.85, (0, 0, 0), (1.55, 0.32, 0.85), detail=1, jitter=0,
                       material=_fxmat("blush", (0.9, 0.16, 0.12), glow=0.35))
        _orient(bl, cp + cn * 0.006, cn)
        parts.append((bl, "face.cheek." + s))
        specs.append(("face.shy." + s, cp + cn * 0.02, cp + cn * (0.02 + rx), hb, up, rx * 3))
        for k in range(3):
            ln = lpm.block(P + "shy%s%d" % (s, k), (rx * 0.2, 0.012, rz * 0.85), (0, 0, 0), material=_fxmat("shy", (0.5, 0.01, 0.01)))
            off = V((rx * 0.5 * (k - 1), 0, 0))
            _orient(ln, cp + cn * 0.028, cn, spin=-28)
            ln.matrix_world = Matrix.Translation(ln.matrix_world.to_3x3() @ off) @ ln.matrix_world
            parts.append((ln, "face.shy." + s))
        # tear at the outer-lower corner
        o_ = V((c.x + sg * rx * 0.6, c.y - 1.0, c.z - rz * 0.85))
        h = face_tree.ray_cast(o_, V((0, 1, 0)))
        tp = (h[0] + (h[1] + fwd).normalized() * 0.02) if h[0] is not None else c + V((sg * rx * 0.6, -ry, -rz))
        specs.append(("fx.tear." + s, tp, tp + up * rx, hb, fwd, rx * 3))
        tm = _fxmat("drop", (0.35, 0.7, 1.0), glow=0.6, rough=0.1)
        tr = rx * 0.24
        parts.append((lpm.ball(P + "tear%s" % s, tr, tp, (1, 0.6, 1), segments=8, rings=4, material=tm), "fx.tear." + s))
        parts.append((lpm.spike(P + "tearT%s" % s, tp + V((0, 0, tr * 0.4)), tp + V((0, 0, tr * 2.4)), tr * 0.75,
                                segments=6, material=tm), "fx.tear." + s))
    # brows: pivot at the head center so raising slides them over the skull
    for s in "LR":
        b = get("brow" + s)
        if b:
            bc = b.matrix_world.translation.copy()
            info["brows"][s] = dict(c=list(Mi @ bc), hc=list(Mi @ hc), hw=b.dimensions.x / 2, hh=b.dimensions.z / 2)
            specs.append(("face.brow." + s, hc, bc, hb, up, (bc - hc).length + 0.1))
            parts.append((b, "face.brow." + s))
    m = get("mouth")
    if m:
        mc = m.matrix_world.translation.copy()
        info["mouth"] = m.name
        specs.append(("face.mouth", mc, mc + fwd * 0.05, hb, up, max(m.dimensions) * 2.5))
        parts.append((m, "face.mouth"))
        _mouth_keys(m)
    # head-wide fx anchored on the whole head silhouette (hair included)
    htree = _world_bvh(head_meshes)
    dm = _fxmat("drop", (0.35, 0.7, 1.0), glow=0.6, rough=0.1)
    sp = _anchor(htree, hc, (0.85, 0, 0.55), 0.09, 0.1)
    specs.append(("fx.sweat", sp, sp + up * 0.1, hb, fwd, 0.2))
    parts.append((lpm.ball(P + "sweat", 0.045, sp, (1, 0.7, 1), segments=10, rings=5, material=dm), "fx.sweat"))
    parts.append((lpm.spike(P + "sweatT", sp + V((0, 0, 0.018)), sp + V((0, 0, 0.11)), 0.034, segments=6, material=dm), "fx.sweat"))
    gm = _fxmat("line", (1.0, 0.85, 0.55), glow=4.0)
    for s, sg in (("L", 1), ("R", -1)):
        segs = []
        for d in ((sg, 0, 0.8), (sg, 0, 0.3), (sg * 0.75, 0, 1.25)):
            d = V(d).normalized()
            p0 = _anchor(htree, hc, d, 0.06, 0.1)
            segs.append((p0, p0 + d * 0.16))
        mid = sum((a + b for a, b in segs), V()) / (2 * len(segs))
        specs.append(("fx.shock." + s, mid, mid + up * 0.1, hb, fwd, 0.3))
        for k, (a, b) in enumerate(segs):
            parts.append((lpm.limb(P + "shock%s%d" % (s, k), a, b, 0.016, segments=6, material=gm), "fx.shock." + s))
    qp = _anchor(htree, hc, (0.55, 0, 0.95), 0.12, 0.1)
    specs.append(("fx.q", qp, qp + up * 0.1, hb, fwd, 0.3))
    pts = [V((0.08 * math.cos(math.radians(a)), 0, 0.2 + 0.075 * math.sin(math.radians(a)))) for a in (165, 120, 70, 20, -30, -75)]
    pts += [V((0.012, 0, 0.09)), V((0.0, 0, 0.06))]
    qm = _fxmat("q", (1.0, 0.82, 0.45), glow=3.0)
    for k in range(len(pts) - 1):
        parts.append((lpm.limb(P + "q%d" % k, qp + pts[k] - V((0, 0, 0.1)), qp + pts[k + 1] - V((0, 0, 0.1)), 0.02,
                               segments=6, material=qm), "fx.q"))
    parts.append((lpm.ball(P + "qdot", 0.024, qp + V((0, 0, -0.08)), segments=8, rings=4, material=qm), "fx.q"))
    km = _fxmat("spark", (1.0, 0.75, 0.25), glow=5.0)
    for i, d in enumerate(((-0.9, 0, 0.75), (0.95, 0, 0.6), (0.25, 0, 1.2))):
        p = _anchor(htree, hc, d, 0.08, 0.1)
        specs.append(("fx.spark%d" % i, p, p + up * 0.05, hb, fwd, 0.2))
        L = 0.075 - 0.012 * i
        for k, v in enumerate(((1, 0, 0), (-1, 0, 0), (0, 0, 1), (0, 0, -1))):
            parts.append((lpm.spike(P + "spark%d%d" % (i, k), p, p + V(v) * L, L * 0.32, segments=4, material=km), "fx.spark%d" % i))
    lpm._CUR = col
    _add_bones(ro, specs)
    bpy.context.view_layer.update()
    for o, bn in parts:
        if o.users_collection and o.users_collection[0] == col and o.parent_bone:
            o["lpf_bone"] = o.parent_bone
        lpm.attach(ro, bn, o)
        if o.users_collection[0] == fxc:
            o.hide_viewport = o.hide_render = True
    # lids start closed-up (scale 0) and hidden
    _neutral_pose(ro)
    info["reach"] = _fit_reach(ro, info)
    ro["lpf"] = json.dumps(info)
    _apply_neutral(ro)
    if not quiet:
        print("lpf setup %s: %d face bones, reach=%s" % (col.name, len(specs), "yes" if info["reach"] else "no"))
    return info


def _mouth_keys(m):
    me = m.data
    if me.shape_keys:
        m.shape_key_clear()
    m.shape_key_add(name="Basis", from_mix=False)
    co = [v.co.copy() for v in me.vertices]
    w = max(abs(c.x) for c in co) or 1e-3
    h = max(abs(c.z) for c in co) or 1e-3
    A = max(w * 0.55, h * 1.4)

    def add(nm, fn):
        k = m.shape_key_add(name=nm, from_mix=False)
        for i, c in enumerate(co):
            k.data[i].co = fn(c.copy())

    def smile(c, sg):
        u = c.x / w
        return V((c.x * 1.2, c.y, c.z + sg * A * (u * u - 0.4)))
    add("smile", lambda c: smile(c, 1))
    add("frown", lambda c: smile(c, -1))
    add("mopen", lambda c: V((c.x * 0.92, c.y - (0.004 if c.z < 0 else 0), c.z * 1.5 + (-h * 2.6 * (-c.z / h) if c.z < 0 else h * 0.5 * c.z / h))))
    add("o", lambda c: V((c.x * 0.72, c.y, c.z * 2.1)))
    add("wide", lambda c: V((c.x * 1.4, c.y, c.z * 0.75)))


def _bone_delta(ro, bn, euler_deg):
    """World matrix that moves a part rigidly attached to bone bn when that bone gets euler_deg (parent at rest)."""
    B = ro.data.bones[bn].matrix_local
    R = Euler([math.radians(a) for a in euler_deg]).to_matrix().to_4x4()
    return ro.matrix_world @ B @ R @ B.inverted() @ ro.matrix_world.inverted()


def _fit_reach(ro, info):
    """Find arm rotations that put each hand on the side of the face without penetrating anything."""
    bones = ro.pose.bones
    if "arm.L" not in bones or "arm.R" not in bones:
        return None
    col = _char_col(ro)
    meshes = [o for o in col.all_objects if o.type == "MESH" and o.parent == ro]
    hb = info["head"]
    facefam = [o for o in meshes if o.parent_bone == hb or o.parent_bone.startswith("face.")]
    others = [o for o in meshes if o not in facefam and not o.parent_bone.startswith("arm.")]
    trees = [(o, _world_bvh([o]), _bbox([o])) for o in facefam + others]
    face = bpy.data.objects[info["face"]]
    lo, hi = _bbox([face])
    hc = (lo + hi) / 2
    ftree = _world_bvh([face])
    out = {}
    for s, sg in (("L", 1), ("R", -1)):
        bn = "arm." + s
        arm = [o for o in meshes if o.parent_bone == bn]
        hand = next((o for o in arm if "hand" in o.name.lower()), None)
        hcen = (sum(_bbox([hand]), V()) / 2) if hand else ro.matrix_world @ ro.data.bones[bn].tail_local
        hr = (sum(hand.dimensions) / 6) if hand else 0.08
        tgt = _anchor(ftree, hc, (sg * 0.95, -0.55, -0.35), hr * 0.85)
        piv = ro.matrix_world @ ro.data.bones[bn].head_local
        jr = bones[bn].get("lpm_joint_r", 0.15)
        verts = [o.matrix_world @ v.co for o in arm for v in o.data.vertices]
        arm_trees = [(_world_bvh([o]), _bbox([o])) for o in arm]
        hpts = []
        for o in facefam:
            mw = o.matrix_world
            hpts += [mw @ v.co for v in o.data.vertices] + [mw @ p.center for p in o.data.polygons]

        def score(x, z):
            M = _bone_delta(ro, bn, (x, 0, z))
            Mi = M.inverted()
            for p in hpts:                      # head poking into the moved arm
                q = Mi @ p
                for t, (blo, bhi) in arm_trees:
                    if all(blo[k] <= q[k] <= bhi[k] for k in range(3)) and _inside(t, q):
                        if t.find_nearest(q)[3] > 0.004:
                            return None
            for v in verts:
                p = M @ v
                for o, t, (blo, bhi) in trees:
                    if any(p[k] < blo[k] or p[k] > bhi[k] for k in range(3)):
                        continue
                    if (p - piv).length < jr and o not in facefam:
                        continue
                    if _inside(t, p):
                        dep = t.find_nearest(p)[3]
                        if dep > 0.004:
                            return None
            return ((M @ hcen) - tgt).length
        best = None
        for x in range(80, 176, 8):
            for z in range(-12, 41, 8):
                sc = score(x, z * sg)
                if sc is not None and (best is None or sc < best[0]):
                    best = (sc, x, z)
        if best:
            for x in range(best[1] - 6, best[1] + 7, 3):
                for z in range(best[2] - 6, best[2] + 7, 3):
                    sc = score(x, z * sg)
                    if sc is not None and sc < best[0]:
                        best = (sc, x, z)
        if not best or best[0] > max(0.14, hr * 1.6):
            return None
        out[s] = [best[1], 0, best[2] * sg]
    return out


# --------------------------------------------------------------------------- timeline engine
def _is_vec(v):
    return isinstance(v, (tuple, list))


def _lerp(a, b, t):
    if _is_vec(a):
        return tuple(x + (y - x) * t for x, y in zip(a, b))
    return a + (b - a) * t


def _eval(keys, f, default):
    if not keys:
        return default
    fs = sorted(keys)
    if f <= fs[0]:
        return keys[fs[0]]
    if f >= fs[-1]:
        return keys[fs[-1]]
    for a, b in zip(fs, fs[1:]):
        if a <= f <= b:
            t = (f - a) / (b - a)
            t = 0.5 - 0.5 * math.cos(math.pi * t)
            return _lerp(keys[a], keys[b], t)


class _TL:
    def __init__(s):
        s.base, s.add, s.mul = {}, {}, {}

    def key(s, f, ch, v):
        s.base.setdefault(ch, {})[round(f)] = v

    def addk(s, f, ch, v, idx=None):
        d = s.add.setdefault(ch, {})
        f = round(f)
        n = NEUTRAL[ch]
        if _is_vec(n):
            cur = list(d.get(f, (0,) * len(n)))
            cur[idx] += v
            d[f] = tuple(cur)
        else:
            d[f] = d.get(f, 0.0) + v

    def mulk(s, f, ch, v):
        s.mul.setdefault(ch, {})[round(f)] = v

    def frames(s, ch):
        return set(s.base.get(ch, {})) | set(s.add.get(ch, {})) | set(s.mul.get(ch, {}))

    def val(s, ch, f):
        n = NEUTRAL[ch]
        v = _eval(s.base.get(ch), f, n)
        a = s.add.get(ch)
        if a:
            fs = sorted(a)
            if fs[0] <= f <= fs[-1]:
                av = _eval(a, f, None)
                v = tuple(x + y for x, y in zip(v, av)) if _is_vec(v) else v + av
        m = s.mul.get(ch)
        if m and not _is_vec(v):
            fs = sorted(m)
            if fs[0] <= f <= fs[-1]:
                v = v * _eval(m, f, 1.0)
        return v


def _scale_peak(peak, I):
    out = {}
    for k, v in peak.items():
        if isinstance(v, str) or k == "happy":
            out[k] = v
            continue
        n = NEUTRAL[k]
        if _is_vec(v):
            out[k] = tuple(nn + (x - nn) * I for x, nn in zip(v, n))
        else:
            out[k] = n + (v - n) * I
            if k in FX:
                out[k] = min(out[k], 1.25)
    return out


def _resolve(preset):
    p = preset.lower().strip().replace(" ", "_").replace("-", "_")
    p = ALIASES.get(p, p)
    if p not in PRESETS and p not in _load_custom():
        raise ValueError("unknown preset %r; have %s" % (preset, ", ".join(presets())))
    return p


def play(name, preset, start=1, length=None, intensity=1.0, speed=1.0, hold=False, clear=True, seed=None,
         blink=True, arms=True, body=True, fx=True, mouth=True, life=True, check_after=True, **over):
    """Key a preset. Overrides: any channel=value (e.g. smile=1.3, head=(0,0,12), blush=0) replaces the
    peak value; arms/body/fx/mouth/blink/life=False drop those parts. speed>1 = faster, intensity scales
    every peak away from neutral. hold=True keeps the expression at the end instead of returning to neutral."""
    ro = _rig(name)
    if not ro.get("lpf"):
        setup(ro, quiet=True)
    info = _info(ro)
    pn = _resolve(preset)
    cust = _load_custom().get(pn)
    if cust and not over.pop("_from_custom", False):
        kw = dict(start=start, length=length, intensity=intensity, speed=speed, hold=hold, clear=clear, seed=seed,
                  blink=blink, arms=arms, body=body, fx=fx, mouth=mouth, life=life, check_after=check_after)
        defaults = dict(start=1, length=None, intensity=1.0, speed=1.0, hold=False, clear=True, seed=None, blink=True,
                        arms=True, body=True, fx=True, mouth=True, life=True, check_after=True)
        merged = {k: v for k, v in cust["opts"].items()}
        merged.update({k: v for k, v in kw.items() if v != defaults[k]})
        merged.update(over)
        for k in ("start", "clear", "check_after"):
            merged[k] = kw[k]
        if cust["base"] in PRESETS:
            return _play_base(name, cust["base"], **merged)
    return _play_base(name, pn, start=start, length=length, intensity=intensity, speed=speed, hold=hold, clear=clear,
                      seed=seed, blink=blink, arms=arms, body=body, fx=fx, mouth=mouth, life=life,
                      check_after=check_after, **over)


def _play_base(name, pn, start=1, length=None, intensity=1.0, speed=1.0, hold=False, clear=True, seed=None,
               blink=True, arms=True, body=True, fx=True, mouth=True, life=True, check_after=True, **over):
    ro = _rig(name)
    info = _info(ro)
    pr = PRESETS[pn]
    fps = bpy.context.scene.render.fps / 24.0
    k = fps / max(speed, 0.05)
    L = int(round((length or pr["len"]) * (k if not length else 1)))
    ramp = max(1, int(round(pr.get("ramp", 8) * k)))
    f1 = start
    fa, fb, fe = f1 + ramp, f1 + L - ramp, f1 + L
    if hold:
        fb = fe
    peak = dict(pr["peak"])
    for ch, v in over.items():
        if ch not in NEUTRAL:
            raise ValueError("unknown channel %r" % ch)
        peak[ch] = tuple(v) if _is_vec(v) else v
    drop = set()
    for flag, grp in ((arms, "arms"), (body, "body"), (fx, "fx"), (mouth, "mouth")):
        if not flag:
            drop |= set(GROUPS[grp])
    peak = {c: v for c, v in peak.items() if c not in drop or c in over}
    reach = None
    for s in "LR":
        if peak.get("arm" + s) == "REACH":
            if info.get("reach"):
                peak["arm" + s] = tuple(info["reach"][s])
                reach = True
            else:
                peak["arm" + s] = (70, 0, 0)
    peak = _scale_peak(peak, intensity)
    if reach and intensity != 1.0:
        for s in "LR":
            peak["arm" + s] = tuple(info["reach"][s])
    if clear:
        reset(ro, keep_setup=True)
    T = _TL()
    rnd = random.Random(seed if seed is not None else hash(pn) & 0xffff)
    os_ = pr.get("overshoot")
    for ch, v in peak.items():
        T.key(f1, ch, NEUTRAL[ch])
        if os_ and ch in ("eye", "brow", "head", "spine", "o", "mopen", "shock", "armL", "armR"):
            n = NEUTRAL[ch]
            T.key(fa, ch, tuple(a + (b - a) * os_ for a, b in zip(n, v)) if _is_vec(v) else n + (v - n) * os_)
            T.key(fa + max(3, int(5 * k)), ch, v)
        else:
            T.key(fa, ch, v)
        T.key(fb, ch, v)
        if not hold:
            T.key(fe, ch, NEUTRAL[ch])
    hs, he = fa + int(3 * k), fb - int(2 * k)
    for item in (pr.get("life", []) if life else []):
        kind = item[0]
        if kind == "blink":
            if not blink or peak.get("happy"):
                continue
            ev = item[1] * k
            f = f1 + rnd.uniform(0.35, 0.8) * ev
            while f < fe - 4 * k:
                b = round(f)
                T.mulk(b - 2, "open", 1.0)
                T.mulk(b, "open", 0.06)
                T.mulk(b + 1, "open", 0.06)
                T.mulk(b + 3, "open", 1.0)
                if rnd.random() < 0.15:          # occasional double blink
                    T.mulk(b + 5, "open", 0.06)
                    T.mulk(b + 7, "open", 1.0)
                f += ev * rnd.uniform(0.7, 1.3)
        elif kind == "osc":
            _, ch, idx, amp, per = item[:5]
            if ch in drop or (ch.endswith("_m") and ch[:-2] not in peak):
                continue
            ph = item[5] if len(item) > 5 else 0.0
            per = per * k
            amp *= intensity if not ch.endswith("_m") else 1
            q = per / 4
            n = int((he - hs) / q)
            for i in range(n + 1):
                f = hs + i * q
                v = 0.0 if i in (0, n) else amp * math.sin(i * math.pi / 2 + ph)
                T.addk(f, ch, v, idx)
        elif kind == "jit":
            _, ch, idx, amp, step = item
            if ch in drop:
                continue
            step = max(1, step * k)
            f, i = hs, 0
            while f <= he:
                T.addk(f, ch, 0.0 if f in (hs,) or f + step > he else rnd.uniform(-amp, amp) * intensity, idx)
                f += step
        elif kind == "talk":
            if not mouth:
                continue
            f = f1 + 2
            while f < fe - 6 * k:
                o = rnd.uniform(0.5, 1.15) * item[1]
                T.addk(f, "mopen", 0.0)
                T.addk(f + 2 * k, "mopen", o)
                if rnd.random() < 0.3:
                    T.addk(f + 2 * k, "o", 0.45)
                    T.addk(f, "o", 0.0)
                    T.addk(f + 5 * k, "o", 0.0)
                f += rnd.choice((4, 5, 6, 7)) * k
                if rnd.random() < 0.12:
                    f += 8 * k                    # pause between phrases
            T.addk(fe - 4 * k, "mopen", 0.0)
        elif kind == "hop":
            if not body:
                continue
            _, hgt, cnt = item
            span = (he - hs) / cnt
            for i in range(cnt):
                s0 = hs + i * span
                T.addk(s0, "hop", 0.0)
                T.addk(s0 + span * 0.35, "hop", hgt * intensity)
                T.addk(s0 + span * 0.7, "hop", 0.0)
            T.addk(he, "hop", 0.0)
        elif kind == "drip":                     # repeating slide: fx grows, slides down, shrinks, restarts
            fxn, per = item[1], item[2] * k
            if fxn not in peak:
                continue
            pv, f = peak[fxn], fa
            while f + per <= fb:
                T.key(f, fxn + "_m", 0.0)
                T.key(f + 1, fxn, pv)
                T.key(f + per * 0.8, fxn + "_m", 1.0)
                T.key(f + per * 0.8, fxn, pv)
                T.key(f + per - 1, fxn, 0.0)
                T.key(f + per - 1, fxn + "_m", 1.0)
                T.key(f + per, fxn + "_m", 0.0)
                f += per
            T.key(f, fxn, pv)
            T.key(f, fxn + "_m", 0.0)
        elif kind == "slide":
            if item[1] not in peak:
                continue
            T.key(fa, item[1] + "_m", 0.0)
            T.key(fb, item[1] + "_m", 1.0)
            T.key(fe, item[1] + "_m", 0.0)
        elif kind == "at":
            f = round(hs + (he - hs) * item[1])
            for ch, v in item[2].items():
                if ch in drop:
                    continue
                if ch == "open":
                    T.mulk(f - 2, "open", 1.0)
                    T.mulk(f, "open", v)
                    T.mulk(f + 1, "open", v)
                    T.mulk(f + 3, "open", 1.0)
                else:
                    base = T.val(ch, f)
                    T.key(f - int(6 * k), ch, base)
                    T.key(f, ch, v)
                    T.key(f + int(10 * k), ch, base)
    n = _apply(ro, info, T, f1, fe, reach)
    sc = bpy.context.scene
    if clear:
        sc.frame_start, sc.frame_end = f1, fe
    else:
        sc.frame_end = max(sc.frame_end, fe)
    sc.frame_set(f1)
    msg = "PLAY %s '%s' frames %d-%d (%d keys)" % (_char_col(ro).name, pn, f1, fe, n)
    if check_after:
        bad = check(ro, frames=range(f1, fe + 1, 2), quiet=True)
        msg += " | " + ("CLEAN" if not bad else "ISSUES " + "; ".join("f%d %s x %s %.3f" % b for b in bad[:6]))
    print(msg)
    return fe


# --------------------------------------------------------------------------- applying channels
def _side_bones(ro, pre):
    return [(s, pre + s) for s in "LR" if pre + s in ro.pose.bones]


def _fx_objs(ro, bone):
    return [o for o in _meshes(ro, (bone,))]


def _key_vis(objs, fn, frames, thr=0.02):
    """Key hide flags so objects show exactly while fn(frame) > thr (checked every frame)."""
    if not objs or not frames:
        return
    last = None
    for f in range(min(frames), max(frames) + 1):
        vis = fn(f) > thr
        if vis != last:
            for o in objs:
                o.hide_viewport = o.hide_render = not vis
                o.keyframe_insert("hide_viewport", frame=f)
                o.keyframe_insert("hide_render", frame=f)
            last = vis


def _apply(ro, info, T, f1, fe, reach):
    nkeys = 0
    pbs = ro.pose.bones
    rad = math.radians

    def frames_for(*chs):
        fs = set()
        for c in chs:
            fs |= T.frames(c)
        return sorted(fs)

    # body
    for ch in BODY:
        bn = info["head"] if ch == "head" else BONE_OF.get(ch)
        if bn not in pbs:
            continue
        fs = frames_for(ch)
        if not fs:
            continue
        pb = pbs[bn]
        rng = pb.get("lpm_range")
        free = reach and ch in ("armL", "armR")
        for f in fs:
            v = list(T.val(ch, f))
            if rng and not free:
                v = [min(max(v[i], rng[2 * i]), rng[2 * i + 1]) for i in range(3)]
            pb.rotation_euler = [rad(a) for a in v]
            pb.keyframe_insert("rotation_euler", frame=f)
            nkeys += 1
    if reach:
        for bn in ("arm.L", "arm.R"):
            for c in pbs[bn].constraints:
                if c.type == "LIMIT_ROTATION":
                    for f, val in ((f1, 1.0), (f1 + 1, 0.0), (fe - 1, 0.0), (fe, 1.0)):
                        c.influence = val
                        c.keyframe_insert("influence", frame=f)
    fs = frames_for("hop")
    if fs and "root" in pbs:
        for f in fs:
            pbs["root"].location = (0, T.val("hop", f), 0)
            pbs["root"].keyframe_insert("location", frame=f)
            nkeys += 1
    # eyes
    eye_fs = frames_for("eye", "eyeL", "eyeR", "open", "look", "happy")
    for s, bn in _side_bones(ro, "face.eye."):
        r = info["eyes"][s]["r"]
        pb = pbs[bn]
        for f in eye_fs:
            sz = T.val("eye", f) * T.val("eye" + s, f)
            op = max(T.val("open", f), 0.04)
            lx, lz = T.val("look", f)
            pb.scale = (sz, sz, sz * op)
            pb.location = (-lx * r[0], 0, lz * r[2])
            pb.keyframe_insert("scale", frame=f)
            pb.keyframe_insert("location", frame=f)
            nkeys += 2
        hf = frames_for("happy")
        if hf:
            objs = _meshes(ro, (bn,))
            _key_vis(objs, lambda f: 1.0 - T.val("happy", f), hf, thr=0.5)
            hb = "face.hap." + s
            vals = {}
            for f in hf:
                v = T.val("happy", f)
                vals[f] = v
                pbs[hb].scale = (max(v, 0.001),) * 3
                pbs[hb].keyframe_insert("scale", frame=f)
            _key_vis(_meshes(ro, (hb,)), lambda f: T.val("happy", f), hf, thr=0.05)
    lf = frames_for("lid", "lid_tilt")
    if lf:
        for s, bn in _side_bones(ro, "face.lid."):
            sg = -1 if s == "L" else 1
            vals = {}
            for f in lf:
                c = T.val("lid", f)
                vals[f] = c
                pbs[bn].scale = (1, 1, max(c, 0.001))
                pbs[bn].rotation_euler = (0, rad(T.val("lid_tilt", f) * sg), 0)
                pbs[bn].keyframe_insert("scale", frame=f)
                pbs[bn].keyframe_insert("rotation_euler", frame=f)
            _key_vis(_meshes(ro, (bn,)), lambda f: T.val("lid", f), lf)
    # brows (never lower than the current eye top: raise is clamped per frame)
    for s, bn in _side_bones(ro, "face.brow."):
        fs = frames_for("brow", "brow" + s, *(eye_fs if s in info["eyes"] else ()))
        sg = -1 if s == "L" else 1
        bi = info["brows"][s]
        rel = V(bi["c"]) - V(bi["hc"])
        rho, phi = math.hypot(rel.y, rel.z), math.atan2(rel.z, -rel.y)
        for f in fs:
            r1, w1 = T.val("brow", f)
            r2, w2 = T.val("brow" + s, f)
            raise_, worry = r1 + r2, w1 + w2
            if s in info["eyes"]:
                e = info["eyes"][s]
                sz = T.val("eye", f) * T.val("eye" + s, f)
                top = e["c"][2] + e["r"][2] * sz * max(T.val("open", f), 0.04) + T.val("look", f)[1] * e["r"][2] + 0.008
                low = bi["c"][2] - bi["hh"] - bi["hw"] * abs(math.sin(rad(worry)))
                need = max(-1.0, min(1.0, (top - low) / rho + math.sin(phi)))
                raise_ = max(raise_, math.degrees(math.asin(need) - phi))
            pbs[bn].rotation_euler = (rad(raise_), rad(worry * sg), 0)
            pbs[bn].keyframe_insert("rotation_euler", frame=f)
            nkeys += 1
    # mouth
    if info.get("mouth"):
        m = bpy.data.objects[info["mouth"]]
        kb = m.data.shape_keys.key_blocks
        for ch in MOUTH:
            for f in frames_for(ch):
                kb[ch].value = max(-0.3, min(T.val(ch, f), 1.6))
                kb[ch].keyframe_insert("value", frame=f)
                nkeys += 1
    # fx
    fxmap = {"blush": "face.cheek.", "shy": "face.shy.", "tear": "fx.tear.", "shock": "fx.shock.",
             "sweat": "fx.sweat", "q": "fx.q", "spark": "fx.spark"}
    for ch, pre in fxmap.items():
        fs = frames_for(ch, ch + "_m")
        if not fs:
            continue
        bones = [b.name for b in pbs if b.name.startswith(pre)]
        for i, bn in enumerate(bones):
            pb = pbs[bn]
            vals = {}
            for f in fs:
                v = max(T.val(ch, f), 0.0)
                mm = T.val(ch + "_m", f)
                vals[f] = v
                sc_ = max(v * (1 + 0.15 * mm if ch == "shock" else 1), 0.001)
                pb.scale = (sc_,) * 3
                if ch in ("sweat", "tear"):
                    pb.location = (0, -(0.09 if ch == "sweat" else 0.1) * mm, 0)
                    pb.keyframe_insert("location", frame=f)
                elif ch == "q":
                    pb.location = (0, 0.03 * mm, 0)
                    pb.rotation_euler = (0, 0, rad(-8 * mm))
                    pb.keyframe_insert("location", frame=f)
                    pb.keyframe_insert("rotation_euler", frame=f)
                elif ch == "shy":
                    pb.rotation_euler = (0, rad(10 * mm), 0)
                    pb.keyframe_insert("rotation_euler", frame=f)
                elif ch == "spark":
                    pb.rotation_euler = (0, 0, rad(30 * mm * (1 if i % 2 else -1)))
                    pb.keyframe_insert("rotation_euler", frame=f)
                pb.keyframe_insert("scale", frame=f)
                nkeys += 1
            _key_vis(_meshes(ro, (bn,)), lambda f, c=ch: T.val(c, f), fs)
    return nkeys


def _apply_neutral(ro):
    _neutral_pose(ro)
    for pb in ro.pose.bones:
        if pb.name.startswith(("face.lid.", "face.hap.", "face.cheek.", "face.shy.", "fx.")):
            pb.scale = (0.001,) * 3
    fxc = _fx_col(ro, False)
    if fxc:
        for o in fxc.objects:
            o.hide_viewport = o.hide_render = True
    info = _info(ro)
    if info.get("mouth"):
        m = bpy.data.objects[info["mouth"]]
        if m.data.shape_keys:
            for k in m.data.shape_keys.key_blocks[1:]:
                k.value = 0.0
    bpy.context.view_layer.update()


def reset(name, keep_setup=True):
    """Remove all lpf/rig animation and return to the neutral face."""
    ro = _rig(name)
    col = _char_col(ro)
    owners = [ro] + list(col.all_objects) + list((_fx_col(ro, False) or col).objects)
    owners += [o.data.shape_keys for o in owners if o.type == "MESH" and o.data.shape_keys]
    old = {ad.action for ad in (getattr(x, "animation_data", None) for x in owners) if ad and ad.action}
    ro.animation_data_clear()
    for o in list(col.all_objects) + list((_fx_col(ro, False) or col).objects):
        if o.animation_data:
            o.animation_data_clear()
        if o.type == "MESH" and o.data.shape_keys and o.data.shape_keys.animation_data:
            o.data.shape_keys.animation_data_clear()
        if o.type == "MESH" and o.parent == ro and o.parent_bone.startswith("face.eye."):
            o.hide_viewport = o.hide_render = False
    for a in old:                       # don't leave orphan actions behind on every replay
        if a.users == 0:
            bpy.data.actions.remove(a)
    for pb in ro.pose.bones:
        for c in pb.constraints:
            c.influence = 1.0
    if ro.get("lpf"):
        _apply_neutral(ro)
    else:
        _neutral_pose(ro)


# --------------------------------------------------------------------------- verification
_DIRS = [V(d).normalized() for d in ((0.2113, 0.3511, 0.9121), (-0.7071, 0.5257, -0.4733), (0.5773, -0.8165, 0.1361))]


def _inside(tree, p):
    """Robust point-in-closed-mesh: ray parity voted over 3 skew directions (one grazing ray can't fool it)."""
    votes = 0
    for d in _DIRS:
        n, o = 0, p.copy()
        for _ in range(64):
            hit = tree.ray_cast(o, d)
            if hit[0] is None:
                break
            n += 1
            o = hit[0] + d * 1e-5
        votes += n % 2
        if votes >= 2 or (votes == 0 and d is _DIRS[1]):
            break
    return votes >= 2


def check(name, frames=None, tol=0.015, quiet=False):
    """Collision test over animated frames: parts on different moving bones must not interpenetrate
    (head + all face/fx bones count as one group). Also flags eyes pushing through brows."""
    ro = _rig(name)
    info = _info(ro)
    hb = info.get("head", "head")
    sc = bpy.context.scene
    frames = list(frames or range(sc.frame_start, sc.frame_end + 1, 2))
    fam = lambda bn: hb if (bn == hb or bn.startswith(("face.", "fx."))) else bn
    bad = {}
    cur = sc.frame_current
    for f in frames:
        sc.frame_set(f)
        dg = bpy.context.evaluated_depsgraph_get()
        ms = [o for o in _meshes(ro) if not o.hide_viewport]
        data = {o.name: lpm._world(o, dg) for o in ms}
        for i, a in enumerate(ms):
            for b in ms[i + 1:]:
                ga, gb = fam(a.parent_bone), fam(b.parent_bone)
                face_pair = ga == gb == hb and ({a.parent_bone[:9], b.parent_bone[:9]} == {"face.eye.", "face.brow"})
                if ga == gb and not face_pair:
                    continue
                ta, pa, la, ha = data[a.name]
                tb, pb_, lb, hb_ = data[b.name]
                if any(ha[k] < lb[k] or hb_[k] < la[k] for k in range(3)):
                    continue
                piv = []
                if not face_pair:
                    for g in (ga, gb):
                        bb = ro.pose.bones[g]
                        piv.append((ro.matrix_world @ bb.head, bb.get("lpm_joint_r", 0.15)))
                worst = 0.0
                for pts, tree in ((pa, tb), (pb_, ta)):
                    for p in pts:
                        if any((p - c).length < r for c, r in piv):
                            continue
                        if _inside(tree, p):
                            worst = max(worst, tree.find_nearest(p)[3])
                lim = 0.004 if face_pair else tol
                if worst > lim:
                    key = (a.name, b.name)
                    if worst > bad.get(key, (0, 0))[1]:
                        bad[key] = (f, worst)
    sc.frame_set(cur)
    out = sorted(((f, a, b, w) for (a, b), (f, w) in bad.items()), key=lambda x: -x[3])
    if not quiet:
        print("CLEAN" if not out else "ISSUES\n" + "\n".join("  f%d %s x %s %.3f" % x for x in out[:20]))
    return out


# --------------------------------------------------------------------------- preview
def gallery(name, path, names=None, frac=0.45, res=260, cols=4, framing="upper", **opts):
    """Play each preset and render one frame of it (at `frac` of its length) into one tiled png."""
    import numpy as np
    names = names or presets()
    tiles = []
    base = os.path.splitext(path)[0]
    for i, n in enumerate(names):
        fe = play(name, n, check_after=False, **opts)
        f = round(1 + (fe - 1) * frac)
        t = sheet(name, base + "_g%d.png" % i, frames=[f], res=res, framing=framing)
        tiles.append(t)
    imgs = []
    for t in tiles:
        im = bpy.data.images.load(t, check_existing=False)
        imgs.append(np.array(im.pixels[:], dtype=np.float32).reshape(res, res, 4))
        bpy.data.images.remove(im)
        os.remove(t)
    rows = (len(imgs) + cols - 1) // cols
    out = np.zeros((rows * res, cols * res, 4), dtype=np.float32)
    out[..., 3] = 1
    for i, a in enumerate(imgs):
        rr, cc = i // cols, i % cols
        out[(rows - 1 - rr) * res:(rows - rr) * res, cc * res:(cc + 1) * res] = a
    im = bpy.data.images.new("lpf_gallery", cols * res, rows * res, alpha=True)
    im.pixels.foreach_set(out.ravel())
    im.filepath_raw = path
    im.file_format = "PNG"
    im.save()
    bpy.data.images.remove(im)
    print("GALLERY " + ", ".join(names))
    return path


def sheet(name, path, frames=None, res=300, cols=None, framing="upper", samples=8, azimuth=0, elevation=6):
    """Render several frames side by side into ONE png (cheap to look at). framing: 'face' | 'upper' | 'full'."""
    import numpy as np
    ro = _rig(name)
    col = _char_col(ro)
    sc = bpy.context.scene
    if frames is None:
        a, b = sc.frame_start, sc.frame_end
        frames = [round(a + (b - a) * t) for t in (0.0, 0.2, 0.4, 0.6, 0.8)]
    if "LPM_Stage" not in bpy.data.collections:
        lpm.stage()
    info = _info(ro)
    hb = info.get("head", "head")
    if framing == "full":
        objs = [o for o in col.all_objects if o.type == "MESH"]
    else:
        objs = [o for o in col.all_objects if o.type == "MESH" and o.parent == ro and
                (o.parent_bone == hb or o.parent_bone.startswith("face."))]
    sc.frame_set(sc.frame_start)
    _neutral_eval = None
    if framing == "face":
        objs = [o for o in col.all_objects if o.type == "MESH" and o.parent == ro and o.parent_bone.startswith("face.")]
    lo, hi = _bbox(objs)
    if framing == "face":
        c_, e_ = (lo + hi) / 2, max(hi.x - lo.x, hi.z - lo.z) * 1.15
        lo, hi = c_ - V((e_, 0, e_ * 0.85)), c_ + V((e_, 0, e_ * 1.15))
    if framing == "upper":
        lo.z -= (hi.z - lo.z) * 0.55
    ctr = (lo + hi) / 2
    size = max(hi.x - lo.x, hi.z - lo.z) * (1.25 if framing != "face" else 1.1)
    cam = bpy.data.objects.get("LPF_Cam") or bpy.data.objects.new("LPF_Cam", bpy.data.cameras.new("LPF_Cam"))
    if not cam.users_collection:
        bpy.data.collections["LPM_Stage"].objects.link(cam)
    cam.data.lens = 70
    dist = size / (2 * math.tan(cam.data.angle / 2))
    az, el = math.radians(azimuth), math.radians(elevation)
    d = V((math.sin(az) * math.cos(el), -math.cos(az) * math.cos(el), math.sin(el)))
    cam.location = ctr + d * dist
    cam.rotation_euler = (-d).to_track_quat("-Z", "Y").to_euler()
    old_cam = sc.camera
    sc.camera = cam
    r = sc.render
    r.engine = "BLENDER_EEVEE"
    r.resolution_x = r.resolution_y = res
    r.resolution_percentage = 100
    r.image_settings.file_format = "PNG"
    try:
        sc.eevee.taa_render_samples = samples
        sc.view_settings.view_transform = "Standard"
    except Exception:
        pass
    keep = set(col.all_objects) | set(bpy.data.collections["LPM_Stage"].all_objects)
    fxc = _fx_col(ro, False)
    if fxc:
        keep |= set(fxc.all_objects)
    hidden = [o for o in sc.objects if o not in keep and not o.hide_render]
    for o in hidden:
        o.hide_render = True
    tiles = []
    cur = sc.frame_current
    tmp = os.path.join(os.path.dirname(path) or ".", "_lpf_tile.png")
    try:
        for f in frames:
            sc.frame_set(f)
            r.filepath = tmp
            bpy.ops.render.render(write_still=True)
            img = bpy.data.images.load(tmp, check_existing=False)
            a = np.array(img.pixels[:], dtype=np.float32).reshape(res, res, 4)
            bpy.data.images.remove(img)
            tiles.append(a)
    finally:
        for o in hidden:
            o.hide_render = False
        sc.camera = old_cam or cam
        sc.frame_set(cur)
        if os.path.exists(tmp):
            os.remove(tmp)
    cols = cols or len(tiles)
    rows = (len(tiles) + cols - 1) // cols
    out = np.zeros((rows * res, cols * res, 4), dtype=np.float32)
    out[..., 3] = 1
    for i, t in enumerate(tiles):
        rr, cc = i // cols, i % cols
        out[(rows - 1 - rr) * res:(rows - rr) * res, cc * res:(cc + 1) * res] = t
    im = bpy.data.images.new("lpf_sheet", cols * res, rows * res, alpha=True)
    im.pixels.foreach_set(out.ravel())
    im.filepath_raw = path
    im.file_format = "PNG"
    im.save()
    bpy.data.images.remove(im)
    return path
