---
name: lowpolyface
description: Animate facial expressions and simple gestures on low-poly characters built with the lowpolymodel skill (lpm) in the user's running Blender. Ready presets for happy, joy, sad, scared, shocked, curious, shy, angry, sleepy, blink, talk, nod yes/no (with smile/sad) using blinks, brow raises, mouth shapes, eye size, lids, blush, sweat/tears/shock lines/? marks and safe arm poses, all collision-checked. Use when the user runs /lowpolyface or asks to animate, emote, make a lowpoly/lpm character talk, blink, nod, react or show an emotion, or to tweak such an animation ("bigger smile", "slower", "no hands").
---

# lowpolyface

Animates the face (and a little body) of characters built with `lowpolymodel` (any lpm build: chibi
humans, robots with glowing screen faces, buddies). Everything is preset-driven, so a request is usually
**one call**. Don't re-derive how faces work; the library already does it.

## Talk to Blender
```bash
python3 ~/.claude/skills/lowpolyface/scripts/fsend.py -c "import lpf; lpf.play('GokuBoy', 'happy')"
```
`fsend.py` auto-loads `lpm` and `lpf` (and reloads them when the files change). If the connection is
refused, ask the user to start the BlenderMCP add-on server in Blender.

**Character name** = its collection name (e.g. `GokuBoy`, `Chibi`, `Bot`). If unknown:
`fsend.py -c "import bpy; print([c.name for c in bpy.data.collections if any(o.type=='ARMATURE' for o in c.objects)])"`

## Workflow (cheap)
1. Map the request to a preset + options with the tables below. Vague is fine: pick the closest preset.
2. `lpf.play(NAME, PRESET, **opts)` prints `PLAY ... frames a-b (n keys) | CLEAN` (or `ISSUES` = collisions).
   The first call auto-runs `lpf.setup(NAME)`, which adds face bones and FX once and keeps lpm's `check()` clean.
3. Look once: `lpf.sheet(NAME, '<scratchpad>/s.png', framing='face')` renders 5 frames into one PNG, then Read it.
   Use `framing='upper'` when arms move (joy, scared, shocked, shy) and `frames=[...]` to pick frames.
4. If the user dislikes something, re-run `play` with options from the tweak table. Never edit lpf.py for a one-off.
   For a tweak they want to keep, use `lpf.save_preset('my_happy', 'happy', smile=1.4, speed=0.8)`, which persists across sessions.
   Saving under a built-in name replaces that built-in for this user.
5. Report the preset, frame range, what moves, and that the check is CLEAN. Don't save the .blend unless asked.

Several clips: `lpf.seq(NAME, ['blink', ('talk', {'speed': 1.2}), 'nod_yes_smile'])`.
Hold the final expression (no return to neutral): `hold=True`. Remove all animation: `lpf.reset(NAME)`.
Compare options at a glance: `lpf.gallery(NAME, path, ['happy','joy','shy'], framing='face')` shows one frame each.

## Presets (24 fps; every clip starts and ends neutral, so it loops)
| preset | what you see | aliases |
|---|---|---|
| happy | smile, soft squint, raised brows, light blush, head tilt + bob | glad, smile |
| joy | ^ ^ eyes, open laugh, arms up, 2 hops, sparkles, blush | excited, joyful |
| sad | worried brows, droopy lids, frown, head down, tears slide | upset |
| cry | sadder face, heavy lids, sobbing shoulders/head, quivering open mouth, **tears that keep dripping** | crying, sob |
| scared | worried brows, wavy mouth, **hands on the sides of the face**, trembling, sweat drop | afraid, fear |
| shocked | **eyes grow**, brows shoot up, O mouth, lean back, arms flare, shock lines (snaps in fast) | surprised, wow |
| curious | head tilt, one brow up, eyes look up-side, small o mouth, bobbing **?** | wonder, confused |
| shy | blush + **/// lines**, glance away and down, head turned, small smile, fidgety arms | embarrassed |
| angry | brows down-in, lids lowered inward, frown, head forward, tremor | mad |
| sleepy | heavy lids, slow head droop, near-closed moment | tired |
| blink | idle blinking with small glances | idle |
| talk | talking mouth + blinks + small head motion | speak |
| talk_gesture | talking + both arms gesturing (forward/out, out of phase) + slight body turn | gesture, talk_arms |
| nod_yes / nod_no | head nods / side-to-side shake | yes, no, shake |
| nod_yes_smile / nod_no_sad | the same, with a smile / a sad face | |

## Tweak table (vague prompt → options)
| user says | pass |
|---|---|
| more / stronger / exaggerate · subtler / softer | `intensity=1.3` · `intensity=0.6` |
| slower / faster | `speed=0.7` · `speed=1.4` |
| longer / shorter (frames) | `length=120` |
| keep the face at the end | `hold=True` |
| no hands / no arm movement | `arms=False` |
| face only (no head or body) | `body=False` |
| no effects (no blush, drops, lines, ?) | `fx=False`, or one off, e.g. `blush=0`, `tear=0` |
| no blinking | `blink=False` |
| still face, no secondary motion | `life=False` |
| bigger smile / open mouth / O mouth | `smile=1.4` · `mopen=0.8` · `o=1` |
| sadder mouth | `frown=1.3` |
| bigger / smaller eyes | `eye=1.35` · `eye=0.85` |
| sleepy / half-closed eyes | `lid=0.5` |
| raise brows / worried / angry brows | `brow=(12,0)` · `brow=(0,22)` · `brow=(-2,-22)` (raise°, worry°) |
| one brow up | `browL=(12,0)` |
| look left / up | `look=(-0.35,0)` · `look=(0,0.3)` (x,z in eye radii; +x = character's left) |
| tilt / turn / nod the head | `head=(x,y,z)` degrees: x+ looks down, y+ turns to its left, z tilts |
| add blush to anything | `blush=0.8` |
| add tears / sweat / ? / sparkles / shock lines | `tear=1` (also `life` slides it) · `sweat=1` · `q=1` · `spark=1` · `shock=1` |
| happy closed ^ ^ eyes | `happy=1, open=0.1` |
| different random variation | `seed=3` |

Any channel can be overridden on any preset (e.g. a talk with a sad face: `play(N,'talk', frown=0.8, brow=(0,18), lid=0.3)`).
Full channel list and how it maps to bones: `references/channels.md` (read it only for custom work).

## Safety (why it never breaks the model)
- Faces never deform: eyes, brows, lids and FX are rigid parts on small face bones. Only the tiny mouth
  has shape keys. Brows are clamped per frame so they never sink into the eyes, even when eyes grow.
- Body bones are clamped to the rig's tested ranges. The only exception is the **scared hands-on-face pose**,
  which `setup` auto-fits per character with no penetration both ways. During that clip only, its arm limits are muted
  by keyed constraint influence. Characters whose arms can't reach their face fall back to hands-up (70°).
- `play` runs `lpf.check` on every second frame (different bones + eye/brow pairs, 1.5 cm tolerance).
  If it ever says ISSUES, lower `intensity`, remove the named channel, or use `arms=False`.
- After big model edits (rebuilt with lpm), run `lpf.setup(NAME, rebuild=True)`.
